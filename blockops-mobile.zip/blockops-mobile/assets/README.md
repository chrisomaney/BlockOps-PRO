# BlockOps Pro Assets

Replace the following placeholder files with actual BlockOps Pro assets before compiling:

| File | Description | Recommended Size |
|------|-------------|-----------------|
| `icon.png` | App icon (iOS / Android square) | 1024×1024 px |
| `splash.png` | Splash screen image | 1242×2436 px |
| `adaptive-icon.png` | Android adaptive icon foreground | 1024×1024 px (with transparent background) |
| `favicon.png` | Web favicon | 196×196 px |

## Brand Colors

| Token | Hex |
|-------|-----|
| Background | `#0f1117` |
| Primary Blue | `#3b82f6` |
| Primary Dark | `#2563eb` |
| Card | `#161b27` |
| Border | `#1e2535` |
| Text | `#f0f4ff` |
| Muted | `#8892a4` |

## Guidelines

- **icon.png** — Use a white construction/tools icon on a `#3b82f6` (primary blue) background.
- **adaptive-icon.png** — Foreground only (transparent background). The `backgroundColor` in `app.json` is already set to `#0f1117`.
- **splash.png** — Center the BlockOps Pro logo on a `#0f1117` dark background. Use `resizeMode: "contain"`.
- **favicon.png** — A small version of the app icon, 196×196 px minimum.

## Generation Tools

- [expo-image-tool](https://github.com/nickvdyck/expo-image-tool) — Auto-generates all required asset sizes from a single source image.
- [Figma](https://figma.com) — Design the icon and export as PNG.
- `npx expo-splash-screen --background-color "#0f1117" --image ./assets/icon.png` — Generate splash screen.
