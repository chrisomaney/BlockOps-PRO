/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './app/**/*.{js,jsx,ts,tsx}',
    './components/**/*.{js,jsx,ts,tsx}',
    './lib/**/*.{js,jsx,ts,tsx}',
  ],
  presets: [require('nativewind/preset')],
  theme: {
    extend: {
      colors: {
        background: '#0f1117',
        card: '#161b27',
        border: '#1e2535',
        primary: '#3b82f6',
        'primary-dark': '#2563eb',
        foreground: '#f0f4ff',
        muted: '#8892a4',
        danger: '#ef4444',
        success: '#22c55e',
        warning: '#f59e0b',
      },
      borderRadius: {
        card: '12px',
        input: '8px',
      },
      fontFamily: {
        sans: ['System'],
      },
    },
  },
  plugins: [],
};
