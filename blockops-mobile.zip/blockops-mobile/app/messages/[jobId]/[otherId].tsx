import React, { useState, useRef, useCallback, useEffect } from 'react';
import {
  View,
  Text,
  FlatList,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Alert,
} from 'react-native';
import { useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { getMessages, sendMessage, Message } from '../../../lib/api';
import { useAuth } from '../../../lib/auth';

// ─── Message Bubble ───────────────────────────────────────────────────────────

function MessageBubble({ message, isMine }: { message: Message; isMine: boolean }) {
  const timeStr = message.createdAt
    ? new Date(message.createdAt).toLocaleTimeString('en-AU', {
        hour: '2-digit',
        minute: '2-digit',
      })
    : '';

  return (
    <View
      className={`mb-3 max-w-[80%] ${isMine ? 'self-end' : 'self-start'}`}
    >
      <View
        className={`rounded-2xl px-4 py-3 ${
          isMine
            ? 'bg-primary rounded-br-sm'
            : 'bg-card border border-border rounded-bl-sm'
        }`}
      >
        <Text
          className={`text-sm leading-relaxed ${isMine ? 'text-white' : 'text-foreground'}`}
        >
          {message.content}
        </Text>
      </View>
      {timeStr && (
        <Text
          className={`text-muted text-xs mt-1 ${isMine ? 'text-right' : 'text-left'}`}
        >
          {timeStr}
        </Text>
      )}
    </View>
  );
}

// ─── Screen ───────────────────────────────────────────────────────────────────

export default function MessageThreadScreen() {
  const { jobId, otherId } = useLocalSearchParams<{ jobId: string; otherId: string }>();
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const [inputText, setInputText] = useState('');
  const flatListRef = useRef<FlatList>(null);

  // Poll for new messages every 5 seconds
  const { data: messages, isLoading, error } = useQuery({
    queryKey: ['messages', jobId, otherId],
    queryFn: () => getMessages(jobId, otherId),
    refetchInterval: 5000,
    staleTime: 0,
  });

  // Scroll to bottom when messages change
  useEffect(() => {
    if (messages && messages.length > 0) {
      setTimeout(() => {
        flatListRef.current?.scrollToEnd({ animated: true });
      }, 100);
    }
  }, [messages?.length]);

  const mutation = useMutation({
    mutationFn: sendMessage,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['messages', jobId, otherId] });
      queryClient.invalidateQueries({ queryKey: ['conversations'] });
      setInputText('');
    },
    onError: (err: any) => {
      Alert.alert('Send Failed', err?.response?.data?.message ?? 'Please try again.');
    },
  });

  const handleSend = useCallback(() => {
    const text = inputText.trim();
    if (!text) return;
    mutation.mutate({
      jobId,
      receiverId: otherId,
      content: text,
    });
  }, [inputText, jobId, otherId, mutation]);

  if (isLoading) {
    return (
      <View className="flex-1 bg-background items-center justify-center">
        <ActivityIndicator size="large" color="#3b82f6" />
        <Text className="text-muted text-sm mt-3">Loading messages…</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View className="flex-1 bg-background items-center justify-center px-6">
        <Ionicons name="cloud-offline-outline" size={48} color="#ef4444" />
        <Text className="text-danger text-base mt-3 text-center">Failed to load messages</Text>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView
      className="flex-1 bg-background"
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={90}
    >
      {/* Message list */}
      {messages && messages.length === 0 ? (
        <View className="flex-1 items-center justify-center">
          <Ionicons name="chatbubbles-outline" size={48} color="#1e2535" />
          <Text className="text-muted text-base mt-4">No messages yet</Text>
          <Text className="text-muted/60 text-sm mt-1">Say hello to get started!</Text>
        </View>
      ) : (
        <FlatList
          ref={flatListRef}
          data={messages}
          keyExtractor={(item) => String(item.id)}
          renderItem={({ item }) => (
            <MessageBubble
              message={item}
              isMine={String(item.senderId) === String(user?.id)}
            />
          )}
          contentContainerStyle={{
            paddingHorizontal: 16,
            paddingTop: 12,
            paddingBottom: 8,
          }}
          showsVerticalScrollIndicator={false}
          onContentSizeChange={() => {
            flatListRef.current?.scrollToEnd({ animated: false });
          }}
        />
      )}

      {/* Input bar */}
      <View className="flex-row items-end gap-3 px-4 py-3 border-t border-border bg-card">
        <TextInput
          className="flex-1 bg-background border border-border rounded-xl px-4 py-3 text-foreground text-sm"
          placeholder="Type a message..."
          placeholderTextColor="#8892a4"
          value={inputText}
          onChangeText={setInputText}
          multiline
          maxLength={1000}
          textAlignVertical="top"
          style={{ maxHeight: 100 }}
          returnKeyType="send"
          onSubmitEditing={handleSend}
          blurOnSubmit={false}
        />
        <TouchableOpacity
          onPress={handleSend}
          disabled={!inputText.trim() || mutation.isPending}
          activeOpacity={0.7}
          className={`w-11 h-11 rounded-full items-center justify-center ${
            inputText.trim() && !mutation.isPending ? 'bg-primary' : 'bg-border'
          }`}
        >
          {mutation.isPending ? (
            <ActivityIndicator size="small" color="#fff" />
          ) : (
            <Ionicons name="send" size={18} color="#fff" />
          )}
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}
