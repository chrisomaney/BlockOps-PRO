import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import * as DocumentPicker from 'expo-document-picker';
import { useMutation } from '@tanstack/react-query';
import { createTradieProfile, selectPlan, uploadDocument } from '../../lib/api';
import PlanCard from '../../components/PlanCard';

// ─── Constants ────────────────────────────────────────────────────────────────

const TRADE_TYPES = [
  'Plumbing', 'Electrical', 'HVAC', 'Carpentry', 'Painting',
  'Roofing', 'Tiling', 'Landscaping', 'Cleaning', 'Pest Control',
  'Security', 'Locksmith', 'Glazing', 'Flooring', 'General Maintenance',
];

const TRADIE_PLANS = [
  {
    id: 'starter',
    name: 'Starter',
    price: 39,
    period: '/month',
    credits: 5,
    features: ['5 job credits', 'Basic profile listing', 'Job board access', 'In-app messaging'],
    highlighted: false,
  },
  {
    id: 'pro',
    name: 'Pro',
    price: 59,
    period: '/month',
    credits: 12,
    features: ['12 job credits', 'Priority profile listing', 'Verified badge', 'Digital contracts', 'Analytics dashboard'],
    highlighted: true,
  },
  {
    id: 'elite',
    name: 'Elite',
    price: 99,
    period: '/month',
    credits: 25,
    features: ['25 job credits', 'Featured placement', 'All Pro features', 'Dedicated support', 'Lead guarantees'],
    highlighted: false,
  },
];

const DOCUMENT_TYPES = [
  { key: 'licence', label: 'Trade Licence', required: true, icon: 'card-outline' },
  { key: 'insurance', label: 'Public Liability Insurance', required: true, icon: 'shield-outline' },
  { key: 'abn_registration', label: 'ABN Registration', required: true, icon: 'document-text-outline' },
  { key: 'police_check', label: 'Police Check (< 12 months)', required: false, icon: 'person-outline' },
  { key: 'wwcc', label: "Working With Children Check", required: false, icon: 'people-outline' },
];

// ─── Step Indicator ───────────────────────────────────────────────────────────

function StepIndicator({ current, total }: { current: number; total: number }) {
  return (
    <View className="flex-row items-center justify-center gap-2 mb-6">
      {Array.from({ length: total }).map((_, i) => (
        <View
          key={i}
          className={`h-1.5 rounded-full transition-all ${
            i + 1 === current
              ? 'bg-primary w-8'
              : i + 1 < current
              ? 'bg-primary/40 w-4'
              : 'bg-border w-4'
          }`}
        />
      ))}
    </View>
  );
}

// ─── Trade Type Chip ──────────────────────────────────────────────────────────

function TradeChip({
  label,
  selected,
  onToggle,
}: {
  label: string;
  selected: boolean;
  onToggle: () => void;
}) {
  return (
    <TouchableOpacity
      onPress={onToggle}
      activeOpacity={0.7}
      className={`px-4 py-2 rounded-full m-1 border ${
        selected ? 'bg-primary border-primary' : 'bg-card border-border'
      }`}
    >
      <Text className={`text-sm ${selected ? 'text-white font-semibold' : 'text-muted'}`}>
        {label}
      </Text>
    </TouchableOpacity>
  );
}

// ─── Document Upload Row ──────────────────────────────────────────────────────

function DocumentRow({
  docType,
  label,
  required,
  icon,
  uploaded,
  fileName,
  onUpload,
}: {
  docType: string;
  label: string;
  required: boolean;
  icon: string;
  uploaded: boolean;
  fileName?: string;
  onUpload: (docType: string) => void;
}) {
  return (
    <View className="bg-card border border-border rounded-xl p-4 mb-3 flex-row items-center gap-4">
      <View
        className={`w-10 h-10 rounded-full items-center justify-center ${
          uploaded ? 'bg-success/20' : 'bg-primary/10'
        }`}
      >
        <Ionicons
          name={uploaded ? 'checkmark-circle' : (icon as any)}
          size={20}
          color={uploaded ? '#22c55e' : '#3b82f6'}
        />
      </View>
      <View className="flex-1">
        <View className="flex-row items-center gap-2">
          <Text className="text-foreground text-sm font-medium">{label}</Text>
          {required && (
            <View className="bg-danger/20 rounded px-1.5 py-0.5">
              <Text className="text-danger text-xs">Required</Text>
            </View>
          )}
        </View>
        {fileName ? (
          <Text className="text-success text-xs mt-0.5" numberOfLines={1}>{fileName}</Text>
        ) : (
          <Text className="text-muted text-xs mt-0.5">Tap to upload PDF or image</Text>
        )}
      </View>
      <TouchableOpacity
        onPress={() => onUpload(docType)}
        className={`px-3 py-2 rounded-lg border ${
          uploaded ? 'border-success' : 'border-primary'
        }`}
      >
        <Text className={`text-xs font-semibold ${uploaded ? 'text-success' : 'text-primary'}`}>
          {uploaded ? 'Replace' : 'Upload'}
        </Text>
      </TouchableOpacity>
    </View>
  );
}

// ─── Screen ───────────────────────────────────────────────────────────────────

export default function TradieOnboardingScreen() {
  const router = useRouter();

  // Step
  const [step, setStep] = useState(1);

  // Step 1: Business details
  const [businessName, setBusinessName] = useState('');
  const [abn, setAbn] = useState('');
  const [selectedTrades, setSelectedTrades] = useState<string[]>([]);
  const [serviceAreas, setServiceAreas] = useState('');
  const [bio, setBio] = useState('');

  // Step 2: Documents
  const [uploadedDocs, setUploadedDocs] = useState<Record<string, { name: string; uri: string; type: string }>>({});

  // Step 3: Plan
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const toggleTrade = (trade: string) => {
    setSelectedTrades((prev) =>
      prev.includes(trade) ? prev.filter((t) => t !== trade) : [...prev, trade],
    );
  };

  const handleDocUpload = async (docType: string) => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: ['application/pdf', 'image/*'],
        copyToCacheDirectory: true,
      });
      if (!result.canceled && result.assets && result.assets.length > 0) {
        const file = result.assets[0];
        setUploadedDocs((prev) => ({
          ...prev,
          [docType]: {
            name: file.name,
            uri: file.uri,
            type: file.mimeType ?? 'application/octet-stream',
          },
        }));
      }
    } catch {
      Alert.alert('Upload Error', 'Could not open file picker. Please try again.');
    }
  };

  const validateStep1 = () => {
    if (!businessName.trim()) {
      Alert.alert('Missing Field', 'Please enter your business name.');
      return false;
    }
    if (!abn.trim() || abn.replace(/\s/g, '').length !== 11) {
      Alert.alert('Invalid ABN', 'Please enter a valid 11-digit ABN.');
      return false;
    }
    if (selectedTrades.length === 0) {
      Alert.alert('Select Trades', 'Please select at least one trade type.');
      return false;
    }
    if (!serviceAreas.trim()) {
      Alert.alert('Missing Field', 'Please enter your service area(s).');
      return false;
    }
    return true;
  };

  const validateStep2 = () => {
    const requiredDocs = DOCUMENT_TYPES.filter((d) => d.required).map((d) => d.key);
    const missingRequired = requiredDocs.filter((key) => !uploadedDocs[key]);
    if (missingRequired.length > 0) {
      const labels = missingRequired.map(
        (key) => DOCUMENT_TYPES.find((d) => d.key === key)?.label ?? key,
      );
      Alert.alert(
        'Missing Documents',
        `Please upload: ${labels.join(', ')}`,
      );
      return false;
    }
    return true;
  };

  const handleComplete = async () => {
    if (!selectedPlan) {
      Alert.alert('Select a Plan', 'Please choose a subscription plan to continue.');
      return;
    }

    setSubmitting(true);
    try {
      // 1. Create tradie profile
      await createTradieProfile({
        businessName: businessName.trim(),
        abn: abn.replace(/\s/g, ''),
        tradeTypes: selectedTrades,
        serviceAreas: serviceAreas
          .split(',')
          .map((s) => s.trim())
          .filter(Boolean),
        bio: bio.trim() || undefined,
      });

      // 2. Upload documents (best effort — non-blocking)
      for (const [docType, file] of Object.entries(uploadedDocs)) {
        try {
          await uploadDocument({
            uri: file.uri,
            name: file.name,
            type: file.type,
            docType,
          });
        } catch {
          // Continue even if individual upload fails
        }
      }

      // 3. Select subscription plan
      await selectPlan(selectedPlan);

      Alert.alert(
        'Setup Complete!',
        'Your tradie profile is submitted for verification. You will be notified once approved.',
        [{ text: 'Get Started', onPress: () => router.replace('/(tabs)/index') }],
      );
    } catch (err: any) {
      Alert.alert(
        'Setup Failed',
        err?.response?.data?.message ?? 'Something went wrong. Please try again.',
      );
    } finally {
      setSubmitting(false);
    }
  };

  const inputClass =
    'bg-card border border-border rounded-xl px-4 py-4 text-foreground text-sm mb-4';

  return (
    <KeyboardAvoidingView
      className="flex-1 bg-background"
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 32 }}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <View className="py-6">
          <StepIndicator current={step} total={3} />
          <Text className="text-muted text-xs text-center mb-6">Step {step} of 3</Text>

          {/* ── Step 1: Business Details ── */}
          {step === 1 && (
            <View>
              <Text className="text-foreground text-2xl font-bold mb-1">
                Business Details
              </Text>
              <Text className="text-muted text-sm mb-6">
                Tell us about your trade business so clients can find you.
              </Text>

              <Text className="text-muted text-xs font-medium mb-1">Business name *</Text>
              <TextInput
                className={inputClass}
                placeholder="Smith Plumbing Services"
                placeholderTextColor="#8892a4"
                value={businessName}
                onChangeText={setBusinessName}
              />

              <Text className="text-muted text-xs font-medium mb-1">ABN *</Text>
              <TextInput
                className={inputClass}
                placeholder="12 345 678 901"
                placeholderTextColor="#8892a4"
                value={abn}
                onChangeText={setAbn}
                keyboardType="number-pad"
                maxLength={14}
              />

              <Text className="text-muted text-xs font-medium mb-1">Service areas *</Text>
              <TextInput
                className={inputClass}
                placeholder="Sydney CBD, Parramatta, North Shore"
                placeholderTextColor="#8892a4"
                value={serviceAreas}
                onChangeText={setServiceAreas}
              />
              <Text className="text-muted text-xs mb-4 -mt-3">Separate multiple areas with commas</Text>

              <Text className="text-muted text-xs font-medium mb-1">Bio (optional)</Text>
              <TextInput
                className={inputClass}
                placeholder="Tell clients about your experience, licences, and what makes you stand out..."
                placeholderTextColor="#8892a4"
                value={bio}
                onChangeText={setBio}
                multiline
                numberOfLines={3}
                textAlignVertical="top"
                style={{ minHeight: 80 }}
              />

              <Text className="text-muted text-xs font-medium mb-3">Trade types * (select all that apply)</Text>
              <View className="flex-row flex-wrap mb-6">
                {TRADE_TYPES.map((trade) => (
                  <TradeChip
                    key={trade}
                    label={trade}
                    selected={selectedTrades.includes(trade)}
                    onToggle={() => toggleTrade(trade)}
                  />
                ))}
              </View>

              <TouchableOpacity
                onPress={() => validateStep1() && setStep(2)}
                className="bg-primary rounded-xl py-4 items-center"
              >
                <Text className="text-white font-bold text-base">Continue</Text>
              </TouchableOpacity>
            </View>
          )}

          {/* ── Step 2: Document Verification ── */}
          {step === 2 && (
            <View>
              <Text className="text-foreground text-2xl font-bold mb-1">
                Document Verification
              </Text>
              <Text className="text-muted text-sm mb-2">
                BlockOps Pro requires document verification for all tradies. This builds trust with commercial clients.
              </Text>
              <View className="bg-primary/10 border border-primary/30 rounded-xl p-3 mb-6 flex-row items-center gap-3">
                <Ionicons name="information-circle" size={20} color="#3b82f6" />
                <Text className="text-muted text-xs flex-1">
                  Your documents are encrypted and reviewed by our verification team within 1–2 business days.
                </Text>
              </View>

              {DOCUMENT_TYPES.map((doc) => (
                <DocumentRow
                  key={doc.key}
                  docType={doc.key}
                  label={doc.label}
                  required={doc.required}
                  icon={doc.icon}
                  uploaded={!!uploadedDocs[doc.key]}
                  fileName={uploadedDocs[doc.key]?.name}
                  onUpload={handleDocUpload}
                />
              ))}

              <View className="flex-row gap-3 mt-4">
                <TouchableOpacity
                  onPress={() => setStep(1)}
                  className="flex-1 border border-border rounded-xl py-4 items-center"
                >
                  <Text className="text-muted font-semibold text-base">Back</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => validateStep2() && setStep(3)}
                  className="flex-2 bg-primary rounded-xl py-4 items-center flex-1"
                >
                  <Text className="text-white font-bold text-base">Continue</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}

          {/* ── Step 3: Choose Plan ── */}
          {step === 3 && (
            <View>
              <Text className="text-foreground text-2xl font-bold mb-1">
                Choose Your Plan
              </Text>
              <Text className="text-muted text-sm mb-6">
                Credits let you express interest in jobs. You can upgrade at any time.
              </Text>

              {TRADIE_PLANS.map((plan) => (
                <PlanCard
                  key={plan.id}
                  plan={plan}
                  selected={selectedPlan === plan.id}
                  onSelect={() => setSelectedPlan(plan.id)}
                />
              ))}

              <View className="flex-row gap-3 mt-4">
                <TouchableOpacity
                  onPress={() => setStep(2)}
                  className="flex-1 border border-border rounded-xl py-4 items-center"
                >
                  <Text className="text-muted font-semibold text-base">Back</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={handleComplete}
                  disabled={!selectedPlan || submitting}
                  className={`flex-1 rounded-xl py-4 items-center ${
                    selectedPlan && !submitting ? 'bg-primary' : 'bg-border'
                  }`}
                >
                  {submitting ? (
                    <ActivityIndicator color="#fff" />
                  ) : (
                    <Text className="text-white font-bold text-base">Complete Setup</Text>
                  )}
                </TouchableOpacity>
              </View>
            </View>
          )}
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
