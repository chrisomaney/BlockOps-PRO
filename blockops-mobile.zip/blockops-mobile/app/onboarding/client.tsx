import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { createClientProfile, selectPlan } from '../../lib/api';
import PlanCard from '../../components/PlanCard';

// ─── Constants ────────────────────────────────────────────────────────────────

const CLIENT_TYPES = [
  { id: 'property_manager', label: 'Property Manager', icon: 'business-outline' },
  { id: 'real_estate', label: 'Real Estate Agency', icon: 'home-outline' },
  { id: 'building_manager', label: 'Building Manager', icon: 'layers-outline' },
  { id: 'strata_manager', label: 'Strata Manager', icon: 'grid-outline' },
  { id: 'facilities_manager', label: 'Facilities Manager', icon: 'settings-outline' },
  { id: 'other', label: 'Other', icon: 'ellipsis-horizontal-outline' },
];

const CLIENT_PLANS = [
  {
    id: 'basic',
    name: 'Basic',
    price: 29,
    period: '/month',
    credits: 5,
    features: ['5 job posts/month', 'Access to verified tradies', 'In-app messaging', 'Lead tracking'],
    highlighted: false,
  },
  {
    id: 'business',
    name: 'Business',
    price: 49,
    period: '/month',
    credits: 15,
    features: ['15 job posts/month', 'Priority tradie matching', 'Digital contracts', 'Analytics & reporting', 'Multi-property support'],
    highlighted: true,
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    price: 79,
    period: '/month',
    credits: -1,
    features: ['Unlimited job posts', 'Dedicated account manager', 'All Business features', 'API access', 'Custom SLA'],
    highlighted: false,
  },
];

// ─── Client Type Selector ─────────────────────────────────────────────────────

function ClientTypeSelector({
  selected,
  onSelect,
}: {
  selected: string;
  onSelect: (type: string) => void;
}) {
  return (
    <View className="flex-row flex-wrap gap-2 mb-4">
      {CLIENT_TYPES.map((type) => {
        const isActive = selected === type.id;
        return (
          <TouchableOpacity
            key={type.id}
            onPress={() => onSelect(type.id)}
            activeOpacity={0.7}
            className={`flex-row items-center gap-2 px-4 py-3 rounded-xl border ${
              isActive ? 'bg-primary/10 border-primary' : 'bg-card border-border'
            }`}
          >
            <Ionicons
              name={type.icon as any}
              size={16}
              color={isActive ? '#3b82f6' : '#8892a4'}
            />
            <Text
              className={`text-sm font-medium ${isActive ? 'text-primary' : 'text-muted'}`}
            >
              {type.label}
            </Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

// ─── Step Indicator ───────────────────────────────────────────────────────────

function StepIndicator({ current, total }: { current: number; total: number }) {
  return (
    <View className="flex-row items-center justify-center gap-2 mb-6">
      {Array.from({ length: total }).map((_, i) => (
        <View
          key={i}
          className={`h-1.5 rounded-full ${
            i + 1 === current ? 'bg-primary w-8' : i + 1 < current ? 'bg-primary/40 w-4' : 'bg-border w-4'
          }`}
        />
      ))}
    </View>
  );
}

// ─── Screen ───────────────────────────────────────────────────────────────────

export default function ClientOnboardingScreen() {
  const router = useRouter();

  const [step, setStep] = useState(1);

  // Step 1: Company details
  const [companyName, setCompanyName] = useState('');
  const [abn, setAbn] = useState('');
  const [clientType, setClientType] = useState('');
  const [address, setAddress] = useState('');

  // Step 2: Plan
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const validateStep1 = () => {
    if (!companyName.trim()) {
      Alert.alert('Missing Field', 'Please enter your company name.');
      return false;
    }
    if (!clientType) {
      Alert.alert('Select Type', 'Please select your client type.');
      return false;
    }
    if (!address.trim()) {
      Alert.alert('Missing Field', 'Please enter your business address.');
      return false;
    }
    return true;
  };

  const handleComplete = async () => {
    if (!selectedPlan) {
      Alert.alert('Select a Plan', 'Please choose a subscription plan to continue.');
      return;
    }

    setSubmitting(true);
    try {
      await createClientProfile({
        companyName: companyName.trim(),
        abn: abn.replace(/\s/g, '') || undefined,
        clientType,
        address: address.trim(),
      });

      await selectPlan(selectedPlan);

      Alert.alert(
        'Setup Complete!',
        'Your client account is ready. Start posting jobs and connecting with verified tradies.',
        [{ text: 'Post Your First Job', onPress: () => router.replace('/(tabs)/jobs') }],
      );
    } catch (err: any) {
      Alert.alert(
        'Setup Failed',
        err?.response?.data?.message ?? 'Something went wrong. Please try again.',
      );
    } finally {
      setSubmitting(false);
    }
  };

  const inputClass =
    'bg-card border border-border rounded-xl px-4 py-4 text-foreground text-sm mb-4';

  return (
    <KeyboardAvoidingView
      className="flex-1 bg-background"
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 32 }}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <View className="py-6">
          <StepIndicator current={step} total={2} />
          <Text className="text-muted text-xs text-center mb-6">Step {step} of 2</Text>

          {/* ── Step 1: Company Details ── */}
          {step === 1 && (
            <View>
              <Text className="text-foreground text-2xl font-bold mb-1">
                Company Details
              </Text>
              <Text className="text-muted text-sm mb-6">
                Tell us about your business so tradies can work with you.
              </Text>

              <Text className="text-muted text-xs font-medium mb-1">Company / business name *</Text>
              <TextInput
                className={inputClass}
                placeholder="Smith Property Management"
                placeholderTextColor="#8892a4"
                value={companyName}
                onChangeText={setCompanyName}
              />

              <Text className="text-muted text-xs font-medium mb-1">ABN (optional)</Text>
              <TextInput
                className={inputClass}
                placeholder="12 345 678 901"
                placeholderTextColor="#8892a4"
                value={abn}
                onChangeText={setAbn}
                keyboardType="number-pad"
                maxLength={14}
              />

              <Text className="text-muted text-xs font-medium mb-3">Business type *</Text>
              <ClientTypeSelector selected={clientType} onSelect={setClientType} />

              <Text className="text-muted text-xs font-medium mb-1 mt-2">Business address *</Text>
              <TextInput
                className={inputClass}
                placeholder="Level 5, 123 George St, Sydney NSW 2000"
                placeholderTextColor="#8892a4"
                value={address}
                onChangeText={setAddress}
                multiline
                numberOfLines={2}
                textAlignVertical="top"
              />

              {/* Trust badges */}
              <View className="bg-card border border-border rounded-xl p-4 mb-6">
                <Text className="text-foreground font-semibold text-sm mb-3">
                  Why use BlockOps Pro?
                </Text>
                {[
                  { icon: 'shield-checkmark', text: 'All tradies are verified with ABN, licence & insurance' },
                  { icon: 'document-text', text: 'Digital contracts protect you on every job' },
                  { icon: 'star', text: 'Rated and reviewed tradies you can trust' },
                  { icon: 'time', text: 'Fast response — get quotes in hours, not days' },
                ].map(({ icon, text }) => (
                  <View key={text} className="flex-row items-center gap-3 mb-2">
                    <Ionicons name={icon as any} size={16} color="#3b82f6" />
                    <Text className="text-muted text-xs flex-1">{text}</Text>
                  </View>
                ))}
              </View>

              <TouchableOpacity
                onPress={() => validateStep1() && setStep(2)}
                className="bg-primary rounded-xl py-4 items-center"
              >
                <Text className="text-white font-bold text-base">Continue</Text>
              </TouchableOpacity>
            </View>
          )}

          {/* ── Step 2: Choose Plan ── */}
          {step === 2 && (
            <View>
              <Text className="text-foreground text-2xl font-bold mb-1">
                Choose Your Plan
              </Text>
              <Text className="text-muted text-sm mb-6">
                Each plan includes a monthly post allowance. Upgrade or cancel anytime.
              </Text>

              {CLIENT_PLANS.map((plan) => (
                <PlanCard
                  key={plan.id}
                  plan={plan}
                  selected={selectedPlan === plan.id}
                  onSelect={() => setSelectedPlan(plan.id)}
                />
              ))}

              <View className="flex-row gap-3 mt-4">
                <TouchableOpacity
                  onPress={() => setStep(1)}
                  className="flex-1 border border-border rounded-xl py-4 items-center"
                >
                  <Text className="text-muted font-semibold text-base">Back</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={handleComplete}
                  disabled={!selectedPlan || submitting}
                  className={`flex-1 rounded-xl py-4 items-center ${
                    selectedPlan && !submitting ? 'bg-primary' : 'bg-border'
                  }`}
                >
                  {submitting ? (
                    <ActivityIndicator color="#fff" />
                  ) : (
                    <Text className="text-white font-bold text-base">Complete Setup</Text>
                  )}
                </TouchableOpacity>
              </View>
            </View>
          )}
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
