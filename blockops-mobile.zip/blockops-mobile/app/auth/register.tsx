import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../lib/auth';

type Role = 'tradie' | 'client';

// ─── Role Selector ────────────────────────────────────────────────────────────

function RoleSelector({
  selected,
  onSelect,
}: {
  selected: Role;
  onSelect: (role: Role) => void;
}) {
  return (
    <View className="flex-row gap-3 mb-4">
      {(['tradie', 'client'] as Role[]).map((role) => {
        const isActive = selected === role;
        const icon = role === 'tradie' ? 'construct-outline' : 'business-outline';
        const label = role === 'tradie' ? 'Tradie' : 'Client';
        const description =
          role === 'tradie' ? 'Offer your services' : 'Post jobs for your property';

        return (
          <TouchableOpacity
            key={role}
            onPress={() => onSelect(role)}
            activeOpacity={0.7}
            className={`flex-1 rounded-xl p-4 border ${
              isActive ? 'bg-primary/10 border-primary' : 'bg-card border-border'
            }`}
          >
            <View className="items-center">
              <View
                className={`w-10 h-10 rounded-full items-center justify-center mb-2 ${
                  isActive ? 'bg-primary' : 'bg-border'
                }`}
              >
                <Ionicons name={icon as any} size={20} color={isActive ? '#fff' : '#8892a4'} />
              </View>
              <Text
                className={`font-bold text-sm ${isActive ? 'text-primary' : 'text-muted'}`}
              >
                {label}
              </Text>
              <Text className="text-muted text-xs text-center mt-0.5">{description}</Text>
            </View>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

// ─── Screen ───────────────────────────────────────────────────────────────────

export default function RegisterScreen() {
  const router = useRouter();
  const { register } = useAuth();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [phone, setPhone] = useState('');
  const [role, setRole] = useState<Role>('client');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleRegister = async () => {
    if (!name.trim() || !email.trim() || !password) {
      Alert.alert('Missing Fields', 'Please fill in name, email, and password.');
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email.trim())) {
      Alert.alert('Invalid Email', 'Please enter a valid email address.');
      return;
    }

    if (password.length < 8) {
      Alert.alert('Weak Password', 'Password must be at least 8 characters long.');
      return;
    }

    setLoading(true);
    try {
      await register(name.trim(), email.trim().toLowerCase(), password, role, phone.trim() || undefined);

      // Redirect to the appropriate onboarding flow
      router.replace(role === 'tradie' ? '/onboarding/tradie' : '/onboarding/client');
    } catch (err: any) {
      const msg =
        err?.response?.data?.message ??
        err?.response?.data?.error ??
        'Registration failed. Please try again.';
      Alert.alert('Registration Failed', msg);
    } finally {
      setLoading(false);
    }
  };

  const inputClass =
    'bg-card border border-border rounded-xl px-4 py-4 text-foreground text-sm mb-4';

  return (
    <KeyboardAvoidingView
      className="flex-1 bg-background"
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView
        contentContainerStyle={{ flexGrow: 1 }}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <View className="px-6 py-8">
          {/* Header */}
          <View className="items-center mb-8">
            <View className="w-16 h-16 bg-primary rounded-2xl items-center justify-center mb-4">
              <Ionicons name="person-add" size={32} color="#fff" />
            </View>
            <Text className="text-foreground text-2xl font-bold">Create Account</Text>
            <Text className="text-muted text-sm mt-1">Join BlockOps Pro today</Text>
          </View>

          {/* Role selector */}
          <Text className="text-muted text-xs font-medium mb-2">I am a...</Text>
          <RoleSelector selected={role} onSelect={setRole} />

          {/* Form fields */}
          <Text className="text-muted text-xs font-medium mb-1">Full name</Text>
          <TextInput
            className={inputClass}
            placeholder="John Smith"
            placeholderTextColor="#8892a4"
            value={name}
            onChangeText={setName}
            autoComplete="name"
            textContentType="name"
          />

          <Text className="text-muted text-xs font-medium mb-1">Email address</Text>
          <TextInput
            className={inputClass}
            placeholder="you@example.com"
            placeholderTextColor="#8892a4"
            value={email}
            onChangeText={setEmail}
            autoCapitalize="none"
            keyboardType="email-address"
            autoComplete="email"
            textContentType="emailAddress"
          />

          <Text className="text-muted text-xs font-medium mb-1">Phone (optional)</Text>
          <TextInput
            className={inputClass}
            placeholder="04XX XXX XXX"
            placeholderTextColor="#8892a4"
            value={phone}
            onChangeText={setPhone}
            keyboardType="phone-pad"
            autoComplete="tel"
            textContentType="telephoneNumber"
          />

          <Text className="text-muted text-xs font-medium mb-1">Password</Text>
          <View className="bg-card border border-border rounded-xl px-4 flex-row items-center mb-2">
            <TextInput
              className="flex-1 py-4 text-foreground text-sm"
              placeholder="At least 8 characters"
              placeholderTextColor="#8892a4"
              value={password}
              onChangeText={setPassword}
              secureTextEntry={!showPassword}
              autoComplete="new-password"
              textContentType="newPassword"
            />
            <TouchableOpacity onPress={() => setShowPassword(!showPassword)} className="p-2">
              <Ionicons
                name={showPassword ? 'eye-off-outline' : 'eye-outline'}
                size={20}
                color="#8892a4"
              />
            </TouchableOpacity>
          </View>

          <Text className="text-muted text-xs mb-6">
            By creating an account, you agree to our Terms of Service and Privacy Policy.
          </Text>

          <TouchableOpacity
            onPress={handleRegister}
            disabled={loading}
            activeOpacity={0.8}
            className="bg-primary rounded-xl py-4 items-center mb-4"
          >
            {loading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text className="text-white font-bold text-base">Create Account</Text>
            )}
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => router.push('/auth/login')}
            className="items-center py-3"
          >
            <Text className="text-muted text-sm">
              Already have an account?{' '}
              <Text className="text-primary font-semibold">Sign in</Text>
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
