import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Modal,
  TextInput,
  Alert,
  FlatList,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { getJob, getJobLeads, submitLead } from '../../lib/api';
import { useAuth } from '../../lib/auth';

// ─── Detail Row ───────────────────────────────────────────────────────────────

function DetailRow({ icon, label, value }: { icon: string; label: string; value: string }) {
  return (
    <View className="flex-row items-center gap-3 py-3 border-b border-border">
      <View className="w-9 h-9 bg-primary/10 rounded-full items-center justify-center">
        <Ionicons name={icon as any} size={17} color="#3b82f6" />
      </View>
      <View className="flex-1">
        <Text className="text-muted text-xs">{label}</Text>
        <Text className="text-foreground text-sm font-medium mt-0.5">{value}</Text>
      </View>
    </View>
  );
}

// ─── Express Interest Modal ───────────────────────────────────────────────────

function ExpressInterestModal({
  visible,
  jobId,
  onClose,
}: {
  visible: boolean;
  jobId: string | number;
  onClose: () => void;
}) {
  const queryClient = useQueryClient();
  const [message, setMessage] = useState('');
  const [quote, setQuote] = useState('');

  const mutation = useMutation({
    mutationFn: submitLead,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['leads', jobId] });
      queryClient.invalidateQueries({ queryKey: ['myLeads'] });
      Alert.alert('Interest Submitted!', 'Your lead has been sent to the client.');
      setMessage('');
      setQuote('');
      onClose();
    },
    onError: (err: any) => {
      Alert.alert(
        'Failed to Submit',
        err?.response?.data?.message ?? 'Please try again.',
      );
    },
  });

  const handleSubmit = () => {
    if (!message.trim()) {
      Alert.alert('Add a message', 'Please introduce yourself and describe your experience.');
      return;
    }
    mutation.mutate({
      jobId,
      message: message.trim(),
      quote: quote ? parseFloat(quote) : undefined,
    });
  };

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet">
      <View className="flex-1 bg-background px-5 pt-6">
        <View className="flex-row items-center justify-between mb-5">
          <Text className="text-foreground text-xl font-bold">Express Interest</Text>
          <TouchableOpacity onPress={onClose}>
            <Ionicons name="close" size={26} color="#8892a4" />
          </TouchableOpacity>
        </View>

        <Text className="text-muted text-sm mb-4">
          Submitting this lead will use 1 credit from your account.
        </Text>

        <Text className="text-muted text-xs mb-1 font-medium">Your message *</Text>
        <TextInput
          className="bg-card border border-border rounded-xl px-4 py-3 text-foreground text-sm mb-4"
          placeholder="Introduce yourself, describe your experience and availability..."
          placeholderTextColor="#8892a4"
          value={message}
          onChangeText={setMessage}
          multiline
          numberOfLines={5}
          textAlignVertical="top"
          style={{ minHeight: 120 }}
        />

        <Text className="text-muted text-xs mb-1 font-medium">Your quote (AUD, optional)</Text>
        <TextInput
          className="bg-card border border-border rounded-xl px-4 py-3 text-foreground text-sm mb-6"
          placeholder="e.g. 350"
          placeholderTextColor="#8892a4"
          value={quote}
          onChangeText={setQuote}
          keyboardType="numeric"
        />

        <TouchableOpacity
          onPress={handleSubmit}
          disabled={mutation.isPending}
          activeOpacity={0.8}
          className="bg-primary rounded-xl py-4 items-center"
        >
          {mutation.isPending ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text className="text-white font-semibold text-base">Submit Lead (1 credit)</Text>
          )}
        </TouchableOpacity>
      </View>
    </Modal>
  );
}

// ─── Lead Card ────────────────────────────────────────────────────────────────

function LeadCard({ lead, jobId }: { lead: any; jobId: string }) {
  const router = useRouter();
  const initials = (lead.tradie?.name ?? 'T')
    .split(' ')
    .map((n: string) => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);

  return (
    <View className="bg-card border border-border rounded-xl p-4 mb-3">
      <View className="flex-row items-center gap-3 mb-2">
        <View className="w-10 h-10 bg-primary/20 rounded-full items-center justify-center">
          <Text className="text-primary font-bold text-sm">{initials}</Text>
        </View>
        <View className="flex-1">
          <Text className="text-foreground font-semibold text-sm">
            {lead.tradie?.name ?? 'Tradie'}
          </Text>
          {lead.quote && (
            <Text className="text-primary text-xs font-medium">
              Quote: ${lead.quote.toLocaleString()}
            </Text>
          )}
        </View>
        <View className="px-2 py-1 bg-success/20 rounded-full">
          <Text className="text-success text-xs font-medium capitalize">{lead.status}</Text>
        </View>
      </View>
      {lead.message && (
        <Text className="text-muted text-sm leading-relaxed" numberOfLines={3}>
          {lead.message}
        </Text>
      )}
      <TouchableOpacity
        onPress={() => router.push(`/messages/${jobId}/${lead.tradieId}`)}
        className="flex-row items-center gap-2 mt-3 pt-3 border-t border-border"
      >
        <Ionicons name="chatbubble-outline" size={15} color="#3b82f6" />
        <Text className="text-primary text-sm font-medium">Message Tradie</Text>
      </TouchableOpacity>
    </View>
  );
}

// ─── Screen ───────────────────────────────────────────────────────────────────

export default function JobDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { user, isAuthenticated } = useAuth();
  const router = useRouter();
  const [showModal, setShowModal] = useState(false);

  const { data: job, isLoading, error } = useQuery({
    queryKey: ['job', id],
    queryFn: () => getJob(id),
    enabled: !!id,
  });

  const { data: leads, isLoading: leadsLoading } = useQuery({
    queryKey: ['leads', id],
    queryFn: () => getJobLeads(id),
    enabled: !!id && isAuthenticated,
  });

  if (isLoading) {
    return (
      <View className="flex-1 bg-background items-center justify-center">
        <ActivityIndicator size="large" color="#3b82f6" />
        <Text className="text-muted text-sm mt-3">Loading job…</Text>
      </View>
    );
  }

  if (error || !job) {
    return (
      <View className="flex-1 bg-background items-center justify-center px-6">
        <Ionicons name="alert-circle-outline" size={48} color="#ef4444" />
        <Text className="text-danger text-base mt-3 text-center">Failed to load job</Text>
        <TouchableOpacity onPress={() => router.back()} className="mt-4 px-6 py-3 border border-primary rounded-xl">
          <Text className="text-primary font-semibold">Go Back</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const isTradie = user?.role === 'tradie';
  const isClient = user?.role === 'client';

  return (
    <View className="flex-1 bg-background">
      <ScrollView
        contentContainerStyle={{ padding: 16 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View className="mb-4">
          <View className="flex-row items-start justify-between gap-3">
            <Text className="text-foreground text-2xl font-bold flex-1" numberOfLines={3}>
              {job.title}
            </Text>
            {job.isUrgent && (
              <View className="bg-danger/20 border border-danger rounded-full px-3 py-1">
                <Text className="text-danger text-xs font-bold">URGENT</Text>
              </View>
            )}
          </View>
          <Text className="text-muted text-xs mt-2">
            Posted {job.createdAt ? new Date(job.createdAt).toLocaleDateString('en-AU') : 'recently'}
          </Text>
        </View>

        {/* Details */}
        <View className="bg-card border border-border rounded-xl px-4 mb-5">
          <DetailRow icon="location-outline" label="Location" value={job.location} />
          <DetailRow icon="construct-outline" label="Trade Type" value={job.tradeType} />
          {job.budget && (
            <DetailRow
              icon="cash-outline"
              label="Budget"
              value={`$${job.budget.toLocaleString()} AUD`}
            />
          )}
          <DetailRow
            icon="ellipse-outline"
            label="Status"
            value={job.status?.replace('_', ' ') ?? 'Open'}
          />
        </View>

        {/* Description */}
        {job.description && (
          <View className="bg-card border border-border rounded-xl p-4 mb-5">
            <Text className="text-foreground font-semibold mb-2">Description</Text>
            <Text className="text-muted text-sm leading-relaxed">{job.description}</Text>
          </View>
        )}

        {/* Leads section (clients only) */}
        {isClient && (
          <View className="mb-5">
            <Text className="text-foreground font-bold text-base mb-3">
              Interested Tradies {leads ? `(${leads.length})` : ''}
            </Text>
            {leadsLoading ? (
              <ActivityIndicator color="#3b82f6" />
            ) : leads && leads.length > 0 ? (
              leads.map((lead) => (
                <LeadCard key={String(lead.id)} lead={lead} jobId={String(id)} />
              ))
            ) : (
              <View className="items-center py-8 bg-card border border-border rounded-xl">
                <Ionicons name="hourglass-outline" size={32} color="#1e2535" />
                <Text className="text-muted text-sm mt-2">No tradies yet</Text>
              </View>
            )}
          </View>
        )}
      </ScrollView>

      {/* CTA for tradies */}
      {isTradie && (
        <View className="px-4 pb-6 pt-3 border-t border-border">
          <TouchableOpacity
            onPress={() => {
              if (!isAuthenticated) {
                router.push('/auth/login');
                return;
              }
              setShowModal(true);
            }}
            activeOpacity={0.8}
            className="bg-primary rounded-xl py-4 items-center"
          >
            <Text className="text-white font-bold text-base">Express Interest</Text>
          </TouchableOpacity>
        </View>
      )}

      {!isAuthenticated && (
        <View className="px-4 pb-6 pt-3 border-t border-border">
          <TouchableOpacity
            onPress={() => router.push('/auth/login')}
            className="bg-primary rounded-xl py-4 items-center"
          >
            <Text className="text-white font-bold text-base">Sign In to Apply</Text>
          </TouchableOpacity>
        </View>
      )}

      <ExpressInterestModal
        visible={showModal}
        jobId={id}
        onClose={() => setShowModal(false)}
      />
    </View>
  );
}
