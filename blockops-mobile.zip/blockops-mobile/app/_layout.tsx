import '../global.css';

import React from 'react';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { AuthProvider } from '../lib/auth';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 2,
      staleTime: 1000 * 60 * 5, // 5 minutes
      gcTime: 1000 * 60 * 30,   // 30 minutes cache
      refetchOnWindowFocus: false,
    },
    mutations: {
      retry: 0,
    },
  },
});

export default function RootLayout() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <SafeAreaProvider>
          <StatusBar style="light" backgroundColor="#0f1117" />
          <Stack
            screenOptions={{
              headerStyle: { backgroundColor: '#0f1117' },
              headerTintColor: '#f0f4ff',
              headerTitleStyle: { fontWeight: '600', color: '#f0f4ff' },
              contentStyle: { backgroundColor: '#0f1117' },
              animation: 'slide_from_right',
            }}
          >
            {/* Main tabs — hide header, tab bar handles navigation */}
            <Stack.Screen name="(tabs)" options={{ headerShown: false }} />

            {/* Auth screens */}
            <Stack.Screen
              name="auth/login"
              options={{ title: 'Sign In', headerBackTitle: 'Back' }}
            />
            <Stack.Screen
              name="auth/register"
              options={{ title: 'Create Account', headerBackTitle: 'Back' }}
            />

            {/* Onboarding */}
            <Stack.Screen
              name="onboarding/tradie"
              options={{ title: 'Tradie Setup', headerBackTitle: 'Back' }}
            />
            <Stack.Screen
              name="onboarding/client"
              options={{ title: 'Client Setup', headerBackTitle: 'Back' }}
            />

            {/* Job detail */}
            <Stack.Screen
              name="jobs/[id]"
              options={{ title: 'Job Details', headerBackTitle: 'Back' }}
            />

            {/* Message thread */}
            <Stack.Screen
              name="messages/[jobId]/[otherId]"
              options={{ title: 'Messages', headerBackTitle: 'Back' }}
            />

            {/* Pricing */}
            <Stack.Screen
              name="pricing"
              options={{ title: 'Choose a Plan', headerBackTitle: 'Back' }}
            />
          </Stack>
        </SafeAreaProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}
