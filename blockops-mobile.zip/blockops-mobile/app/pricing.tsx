import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { selectPlan } from '../lib/api';
import { useAuth } from '../lib/auth';
import PlanCard from '../components/PlanCard';

// ─── Plan Data ────────────────────────────────────────────────────────────────

const TRADIE_PLANS = [
  {
    id: 'starter',
    name: 'Starter',
    price: 39,
    period: '/month',
    credits: 5,
    features: [
      '5 job credits per month',
      'Basic profile listing',
      'Job board access',
      'In-app messaging',
      'Standard support',
    ],
    highlighted: false,
  },
  {
    id: 'pro',
    name: 'Pro',
    price: 59,
    period: '/month',
    credits: 12,
    features: [
      '12 job credits per month',
      'Priority profile listing',
      'Verified badge on profile',
      'Digital contracts',
      'Analytics dashboard',
      'Priority support',
    ],
    highlighted: true,
  },
  {
    id: 'elite',
    name: 'Elite',
    price: 99,
    period: '/month',
    credits: 25,
    features: [
      '25 job credits per month',
      'Featured placement in search',
      'Everything in Pro',
      'Dedicated account manager',
      'Lead guarantee program',
      'Early access to new features',
    ],
    highlighted: false,
  },
];

const CLIENT_PLANS = [
  {
    id: 'basic',
    name: 'Basic',
    price: 29,
    period: '/month',
    credits: 5,
    features: [
      '5 job posts per month',
      'Access to verified tradies',
      'In-app messaging',
      'Lead tracking',
      'Standard support',
    ],
    highlighted: false,
  },
  {
    id: 'business',
    name: 'Business',
    price: 49,
    period: '/month',
    credits: 15,
    features: [
      '15 job posts per month',
      'Priority tradie matching',
      'Digital contracts',
      'Analytics & reporting',
      'Multi-property support',
      'Priority support',
    ],
    highlighted: true,
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    price: 79,
    period: '/month',
    credits: -1,
    features: [
      'Unlimited job posts',
      'Dedicated account manager',
      'Everything in Business',
      'API access',
      'Custom SLA agreements',
      'White-label options',
    ],
    highlighted: false,
  },
];

// ─── Tab Toggle ───────────────────────────────────────────────────────────────

function TabToggle({
  active,
  onChange,
}: {
  active: 'tradie' | 'client';
  onChange: (tab: 'tradie' | 'client') => void;
}) {
  return (
    <View className="flex-row bg-card border border-border rounded-xl p-1 mb-6">
      {(['tradie', 'client'] as const).map((tab) => (
        <TouchableOpacity
          key={tab}
          onPress={() => onChange(tab)}
          className={`flex-1 py-3 rounded-lg items-center ${
            active === tab ? 'bg-primary' : 'bg-transparent'
          }`}
        >
          <Text
            className={`font-semibold text-sm capitalize ${
              active === tab ? 'text-white' : 'text-muted'
            }`}
          >
            {tab === 'tradie' ? 'Tradies' : 'Clients'}
          </Text>
        </TouchableOpacity>
      ))}
    </View>
  );
}

// ─── Screen ───────────────────────────────────────────────────────────────────

export default function PricingScreen() {
  const router = useRouter();
  const { user, isAuthenticated } = useAuth();
  const queryClient = useQueryClient();

  // Default to the user's role tab, or client if not logged in
  const defaultTab: 'tradie' | 'client' =
    user?.role === 'tradie' ? 'tradie' : 'client';
  const [activeTab, setActiveTab] = useState<'tradie' | 'client'>(defaultTab);
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);

  const plans = activeTab === 'tradie' ? TRADIE_PLANS : CLIENT_PLANS;

  const mutation = useMutation({
    mutationFn: selectPlan,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['subscription'] });
      Alert.alert(
        'Plan Activated!',
        `You're now on the ${selectedPlan} plan. Enjoy BlockOps Pro!`,
        [{ text: 'OK', onPress: () => router.back() }],
      );
    },
    onError: (err: any) => {
      Alert.alert(
        'Plan Change Failed',
        err?.response?.data?.message ?? 'Please try again.',
      );
    },
  });

  const handleSelectPlan = () => {
    if (!isAuthenticated) {
      router.push('/auth/login');
      return;
    }
    if (!selectedPlan) {
      Alert.alert('Select a Plan', 'Please choose a plan to continue.');
      return;
    }
    mutation.mutate(selectedPlan);
  };

  return (
    <View className="flex-1 bg-background">
      <ScrollView
        contentContainerStyle={{ padding: 16, paddingBottom: 100 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View className="items-center mb-6">
          <Text className="text-foreground text-2xl font-bold">Simple, Fair Pricing</Text>
          <Text className="text-muted text-sm text-center mt-2">
            No hidden fees. Cancel anytime. GST included.
          </Text>
        </View>

        {/* Tab toggle */}
        <TabToggle active={activeTab} onChange={setActiveTab} />

        {/* Plans */}
        {plans.map((plan) => (
          <PlanCard
            key={plan.id}
            plan={plan}
            selected={selectedPlan === plan.id}
            onSelect={() => setSelectedPlan(plan.id)}
          />
        ))}

        {/* FAQ */}
        <View className="mt-4">
          <Text className="text-foreground font-bold text-base mb-4">
            Frequently Asked Questions
          </Text>

          {[
            {
              q: 'Can I change my plan?',
              a: 'Yes, you can upgrade or downgrade at any time. Changes take effect from your next billing cycle.',
            },
            {
              q: 'Do credits roll over?',
              a: 'Credits reset at the start of each billing period and do not roll over to the next month.',
            },
            {
              q: 'Is there a free trial?',
              a: 'We offer a 7-day free trial for new accounts. No credit card required to start.',
            },
            {
              q: 'What payment methods do you accept?',
              a: 'We accept all major credit cards, debit cards, and Australian bank transfers.',
            },
          ].map(({ q, a }) => (
            <View key={q} className="bg-card border border-border rounded-xl p-4 mb-3">
              <Text className="text-foreground font-semibold text-sm mb-1">{q}</Text>
              <Text className="text-muted text-sm leading-relaxed">{a}</Text>
            </View>
          ))}
        </View>
      </ScrollView>

      {/* Bottom CTA */}
      {isAuthenticated && (
        <View className="px-4 pb-6 pt-3 border-t border-border bg-background">
          <TouchableOpacity
            onPress={handleSelectPlan}
            disabled={!selectedPlan || mutation.isPending}
            activeOpacity={0.8}
            className={`rounded-xl py-4 items-center ${
              selectedPlan && !mutation.isPending ? 'bg-primary' : 'bg-border'
            }`}
          >
            {mutation.isPending ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text className="text-white font-bold text-base">
                {selectedPlan
                  ? `Activate ${plans.find((p) => p.id === selectedPlan)?.name ?? ''} Plan`
                  : 'Select a Plan'}
              </Text>
            )}
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}
