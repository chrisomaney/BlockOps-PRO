import React from 'react';
import { Tabs } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../lib/auth';

type IoniconName = keyof typeof Ionicons.glyphMap;

function TabBarIcon({
  name,
  color,
  size = 24,
}: {
  name: IoniconName;
  color: string;
  size?: number;
}) {
  return <Ionicons name={name} size={size} color={color} />;
}

export default function TabsLayout() {
  const { user } = useAuth();

  // Tradies see a briefcase icon; clients see a plus icon for posting jobs
  const jobsIcon: IoniconName =
    user?.role === 'client' ? 'add-circle-outline' : 'briefcase-outline';
  const jobsIconFocused: IoniconName =
    user?.role === 'client' ? 'add-circle' : 'briefcase';

  return (
    <Tabs
      screenOptions={{
        tabBarStyle: {
          backgroundColor: '#161b27',
          borderTopColor: '#1e2535',
          borderTopWidth: 1,
          height: 60,
          paddingBottom: 8,
        },
        tabBarActiveTintColor: '#3b82f6',
        tabBarInactiveTintColor: '#8892a4',
        tabBarLabelStyle: {
          fontSize: 11,
          fontWeight: '500',
        },
        headerStyle: { backgroundColor: '#0f1117' },
        headerTintColor: '#f0f4ff',
        headerTitleStyle: { fontWeight: '700', color: '#f0f4ff' },
        headerShadowVisible: false,
      }}
    >
      {/* Home */}
      <Tabs.Screen
        name="index"
        options={{
          title: 'Home',
          headerTitle: 'BlockOps Pro',
          tabBarIcon: ({ color, focused }) => (
            <TabBarIcon name={focused ? 'home' : 'home-outline'} color={color} />
          ),
        }}
      />

      {/* Jobs */}
      <Tabs.Screen
        name="jobs"
        options={{
          title: 'Jobs',
          tabBarIcon: ({ color, focused }) => (
            <TabBarIcon name={focused ? jobsIconFocused : jobsIcon} color={color} />
          ),
        }}
      />

      {/* Messages */}
      <Tabs.Screen
        name="messages"
        options={{
          title: 'Messages',
          tabBarIcon: ({ color, focused }) => (
            <TabBarIcon
              name={focused ? 'chatbubbles' : 'chatbubbles-outline'}
              color={color}
            />
          ),
        }}
      />

      {/* Dashboard */}
      <Tabs.Screen
        name="dashboard"
        options={{
          title: 'Dashboard',
          tabBarIcon: ({ color, focused }) => (
            <TabBarIcon name={focused ? 'grid' : 'grid-outline'} color={color} />
          ),
        }}
      />
    </Tabs>
  );
}
