import React, { useCallback } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  ScrollView,
  RefreshControl,
  Alert,
} from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { getSubscription, getMyLeads, getJobs } from '../../lib/api';
import { useAuth } from '../../lib/auth';

// ─── Plan Badge ───────────────────────────────────────────────────────────────

function PlanBadge({ plan }: { plan: string }) {
  const colors: Record<string, string> = {
    Starter: '#8892a4',
    Pro: '#3b82f6',
    Elite: '#f59e0b',
    Basic: '#8892a4',
    Business: '#3b82f6',
    Enterprise: '#f59e0b',
  };
  const color = colors[plan] ?? '#8892a4';

  return (
    <View
      style={{ borderColor: color }}
      className="border rounded-full px-3 py-0.5"
    >
      <Text style={{ color }} className="text-xs font-semibold">
        {plan}
      </Text>
    </View>
  );
}

// ─── Subscription Card ────────────────────────────────────────────────────────

function SubscriptionCard() {
  const router = useRouter();
  const { user } = useAuth();
  const isTradie = user?.role === 'tradie';

  const { data: sub, isLoading } = useQuery({
    queryKey: ['subscription'],
    queryFn: getSubscription,
    retry: 1,
  });

  if (isLoading) {
    return (
      <View className="bg-card border border-border rounded-xl p-5 mb-4 items-center">
        <ActivityIndicator color="#3b82f6" />
      </View>
    );
  }

  const remaining = isTradie ? sub?.creditsRemaining : sub?.postsRemaining;
  const remainingLabel = isTradie ? 'Credits remaining' : 'Posts remaining';
  const remainingDisplay = remaining === -1 ? 'Unlimited' : (remaining ?? 0);

  return (
    <View className="bg-card border border-border rounded-xl p-5 mb-4">
      <View className="flex-row items-center justify-between mb-4">
        <Text className="text-foreground font-bold text-base">Your Subscription</Text>
        {sub?.plan && <PlanBadge plan={sub.plan} />}
      </View>

      <View className="flex-row justify-between mb-4">
        <View className="items-center flex-1">
          <Text className="text-primary text-3xl font-bold">{remainingDisplay}</Text>
          <Text className="text-muted text-xs mt-1">{remainingLabel}</Text>
        </View>
        <View className="w-px bg-border" />
        <View className="items-center flex-1">
          <Text className="text-foreground text-base font-semibold capitalize">
            {sub?.status ?? '—'}
          </Text>
          <Text className="text-muted text-xs mt-1">Status</Text>
        </View>
      </View>

      {sub?.expiresAt && (
        <Text className="text-muted text-xs mb-4">
          Renews: {new Date(sub.expiresAt).toLocaleDateString('en-AU')}
        </Text>
      )}

      <TouchableOpacity
        onPress={() => router.push('/pricing')}
        className="border border-primary rounded-xl py-3 items-center"
      >
        <Text className="text-primary font-semibold text-sm">Upgrade Plan</Text>
      </TouchableOpacity>
    </View>
  );
}

// ─── Lead Item (Tradie) ───────────────────────────────────────────────────────

function LeadItem({ lead }: { lead: any }) {
  const router = useRouter();

  const statusColors: Record<string, string> = {
    pending: '#f59e0b',
    accepted: '#22c55e',
    rejected: '#ef4444',
    completed: '#3b82f6',
  };
  const statusColor = statusColors[lead.status] ?? '#8892a4';

  return (
    <TouchableOpacity
      onPress={() => router.push(`/jobs/${lead.jobId}`)}
      activeOpacity={0.7}
      className="bg-card border border-border rounded-xl p-4 mb-3"
    >
      <View className="flex-row items-start justify-between">
        <View className="flex-1">
          <Text className="text-foreground font-semibold text-sm" numberOfLines={1}>
            {lead.job?.title ?? `Job #${lead.jobId}`}
          </Text>
          {lead.job?.location && (
            <View className="flex-row items-center gap-1 mt-1">
              <Ionicons name="location-outline" size={12} color="#8892a4" />
              <Text className="text-muted text-xs">{lead.job.location}</Text>
            </View>
          )}
          {lead.quote && (
            <Text className="text-primary text-sm font-semibold mt-2">
              Quote: ${lead.quote.toLocaleString()}
            </Text>
          )}
        </View>
        <View
          style={{ backgroundColor: statusColor + '22', borderColor: statusColor }}
          className="border rounded-full px-3 py-1"
        >
          <Text style={{ color: statusColor }} className="text-xs font-medium capitalize">
            {lead.status}
          </Text>
        </View>
      </View>
    </TouchableOpacity>
  );
}

// ─── Job Item (Client) ────────────────────────────────────────────────────────

function ClientJobItem({ job }: { job: any }) {
  const router = useRouter();

  const statusColors: Record<string, string> = {
    open: '#22c55e',
    closed: '#8892a4',
    in_progress: '#3b82f6',
    completed: '#f59e0b',
  };
  const statusColor = statusColors[job.status] ?? '#8892a4';

  return (
    <TouchableOpacity
      onPress={() => router.push(`/jobs/${job.id}`)}
      activeOpacity={0.7}
      className="bg-card border border-border rounded-xl p-4 mb-3"
    >
      <View className="flex-row items-start justify-between">
        <View className="flex-1">
          <Text className="text-foreground font-semibold text-sm" numberOfLines={1}>
            {job.title}
          </Text>
          <View className="flex-row items-center gap-1 mt-1">
            <Ionicons name="location-outline" size={12} color="#8892a4" />
            <Text className="text-muted text-xs">{job.location}</Text>
          </View>
          <Text className="text-muted text-xs mt-1">{job.tradeType}</Text>
        </View>
        <View
          style={{ backgroundColor: statusColor + '22', borderColor: statusColor }}
          className="border rounded-full px-3 py-1"
        >
          <Text style={{ color: statusColor }} className="text-xs font-medium capitalize">
            {job.status?.replace('_', ' ')}
          </Text>
        </View>
      </View>
    </TouchableOpacity>
  );
}

// ─── Tradie Dashboard ─────────────────────────────────────────────────────────

function TradieDashboard() {
  const queryClient = useQueryClient();
  const [refreshing, setRefreshing] = React.useState(false);

  const { data: leads, isLoading: leadsLoading } = useQuery({
    queryKey: ['myLeads'],
    queryFn: getMyLeads,
  });

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await queryClient.invalidateQueries({ queryKey: ['myLeads'] });
    await queryClient.invalidateQueries({ queryKey: ['subscription'] });
    setRefreshing(false);
  }, [queryClient]);

  return (
    <ScrollView
      className="flex-1"
      contentContainerStyle={{ padding: 16 }}
      showsVerticalScrollIndicator={false}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#3b82f6" />
      }
    >
      <SubscriptionCard />

      <Text className="text-foreground font-bold text-base mb-3 mt-2">My Leads</Text>

      {leadsLoading ? (
        <View className="items-center py-8">
          <ActivityIndicator color="#3b82f6" />
        </View>
      ) : leads && leads.length > 0 ? (
        leads.map((lead) => <LeadItem key={String(lead.id)} lead={lead} />)
      ) : (
        <View className="items-center py-10">
          <Ionicons name="trending-up-outline" size={40} color="#1e2535" />
          <Text className="text-muted text-sm mt-3 text-center">
            No leads yet. Browse the job board and express interest!
          </Text>
        </View>
      )}
    </ScrollView>
  );
}

// ─── Client Dashboard ─────────────────────────────────────────────────────────

function ClientDashboard() {
  const router = useRouter();
  const queryClient = useQueryClient();
  const [refreshing, setRefreshing] = React.useState(false);

  const { data: jobs, isLoading: jobsLoading } = useQuery({
    queryKey: ['myJobs'],
    queryFn: () => getJobs({}),
  });

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await queryClient.invalidateQueries({ queryKey: ['myJobs'] });
    await queryClient.invalidateQueries({ queryKey: ['subscription'] });
    setRefreshing(false);
  }, [queryClient]);

  return (
    <ScrollView
      className="flex-1"
      contentContainerStyle={{ padding: 16 }}
      showsVerticalScrollIndicator={false}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#3b82f6" />
      }
    >
      <SubscriptionCard />

      <View className="flex-row items-center justify-between mb-3 mt-2">
        <Text className="text-foreground font-bold text-base">My Posted Jobs</Text>
        <TouchableOpacity
          onPress={() => router.push('/(tabs)/jobs')}
          className="flex-row items-center gap-1"
        >
          <Ionicons name="add" size={16} color="#3b82f6" />
          <Text className="text-primary text-sm font-semibold">Post Job</Text>
        </TouchableOpacity>
      </View>

      {jobsLoading ? (
        <View className="items-center py-8">
          <ActivityIndicator color="#3b82f6" />
        </View>
      ) : jobs && jobs.length > 0 ? (
        jobs.map((job) => <ClientJobItem key={String(job.id)} job={job} />)
      ) : (
        <View className="items-center py-10">
          <Ionicons name="folder-open-outline" size={40} color="#1e2535" />
          <Text className="text-muted text-sm mt-3 text-center">
            No jobs posted yet. Post your first job to get started!
          </Text>
        </View>
      )}
    </ScrollView>
  );
}

// ─── Screen ───────────────────────────────────────────────────────────────────

export default function DashboardScreen() {
  const router = useRouter();
  const { user, isAuthenticated, loading, logout } = useAuth();

  const handleLogout = () => {
    Alert.alert('Sign Out', 'Are you sure you want to sign out?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Sign Out',
        style: 'destructive',
        onPress: async () => {
          await logout();
          router.replace('/(tabs)/index');
        },
      },
    ]);
  };

  if (loading) {
    return (
      <View className="flex-1 bg-background items-center justify-center">
        <ActivityIndicator size="large" color="#3b82f6" />
      </View>
    );
  }

  if (!isAuthenticated) {
    return (
      <View className="flex-1 bg-background items-center justify-center px-8">
        <Ionicons name="grid-outline" size={52} color="#1e2535" />
        <Text className="text-foreground text-xl font-bold mt-5 text-center">
          Sign in to view your dashboard
        </Text>
        <Text className="text-muted text-sm mt-2 text-center">
          Track your jobs, leads, and subscription from your personal dashboard.
        </Text>
        <TouchableOpacity
          onPress={() => router.push('/auth/login')}
          className="bg-primary rounded-xl px-8 py-4 mt-6 w-full items-center"
        >
          <Text className="text-white font-semibold text-base">Sign In</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => router.push('/auth/register')}
          className="mt-3 w-full items-center border border-primary rounded-xl py-4"
        >
          <Text className="text-primary font-semibold text-base">Create Account</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View className="flex-1 bg-background">
      {/* Header */}
      <View className="px-4 pt-4 pb-2 flex-row items-center justify-between">
        <View>
          <Text className="text-foreground text-xl font-bold">Dashboard</Text>
          <Text className="text-muted text-xs mt-0.5 capitalize">{user?.role} · {user?.email}</Text>
        </View>
        <TouchableOpacity
          onPress={handleLogout}
          className="flex-row items-center gap-2 border border-border rounded-xl px-3 py-2"
        >
          <Ionicons name="log-out-outline" size={18} color="#8892a4" />
          <Text className="text-muted text-sm">Sign Out</Text>
        </TouchableOpacity>
      </View>

      {user?.role === 'tradie' ? <TradieDashboard /> : <ClientDashboard />}
    </View>
  );
}
