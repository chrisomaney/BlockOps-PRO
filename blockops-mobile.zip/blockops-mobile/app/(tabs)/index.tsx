import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
} from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useQuery } from '@tanstack/react-query';
import { useAuth } from '../../lib/auth';
import { getSubscription, getMyLeads } from '../../lib/api';

// ─── Logo ─────────────────────────────────────────────────────────────────────

function Logo() {
  return (
    <View className="items-center mb-2">
      <View className="flex-row items-center gap-2">
        <View className="w-10 h-10 bg-primary rounded-xl items-center justify-center">
          <Ionicons name="construct" size={22} color="#fff" />
        </View>
        <Text className="text-4xl font-bold text-primary tracking-tight">
          BlockOps
          <Text className="text-foreground"> Pro</Text>
        </Text>
      </View>
      <Text className="text-muted text-sm mt-1">Verified Trades Marketplace</Text>
    </View>
  );
}

// ─── Stat Card ────────────────────────────────────────────────────────────────

function StatCard({ label, value, icon }: { label: string; value: string | number; icon: string }) {
  return (
    <View className="flex-1 bg-card border border-border rounded-xl p-4 items-center mx-1">
      <Ionicons name={icon as any} size={24} color="#3b82f6" />
      <Text className="text-foreground text-2xl font-bold mt-1">{value}</Text>
      <Text className="text-muted text-xs mt-0.5">{label}</Text>
    </View>
  );
}

// ─── Quick Action Button ──────────────────────────────────────────────────────

function ActionButton({
  label,
  icon,
  onPress,
  outline = false,
}: {
  label: string;
  icon: string;
  onPress: () => void;
  outline?: boolean;
}) {
  return (
    <TouchableOpacity
      onPress={onPress}
      activeOpacity={0.8}
      className={`flex-row items-center justify-center gap-3 rounded-xl px-6 py-4 mb-3 ${
        outline
          ? 'border border-primary bg-transparent'
          : 'bg-primary'
      }`}
    >
      <Ionicons name={icon as any} size={20} color={outline ? '#3b82f6' : '#fff'} />
      <Text className={`font-semibold text-base ${outline ? 'text-primary' : 'text-white'}`}>
        {label}
      </Text>
    </TouchableOpacity>
  );
}

// ─── Guest Hero ───────────────────────────────────────────────────────────────

function GuestHero() {
  const router = useRouter();

  return (
    <View className="flex-1 px-6 pt-6">
      <View className="bg-card border border-border rounded-2xl p-6 mb-6">
        <Text className="text-foreground text-xl font-bold mb-2">
          Australia's Verified Trades Marketplace
        </Text>
        <Text className="text-muted text-sm leading-relaxed">
          Connect commercial property managers and real estate agents with fully verified, insured tradies. Every job covered. Every tradie checked.
        </Text>
      </View>

      {/* Feature highlights */}
      {[
        { icon: 'shield-checkmark', label: 'Fully verified tradies with ABN, license & insurance checks' },
        { icon: 'document-text', label: 'Digital contracts and e-signatures built in' },
        { icon: 'chatbubbles', label: 'Secure in-app messaging on every job' },
        { icon: 'star', label: 'Ratings and reviews for quality assurance' },
      ].map(({ icon, label }) => (
        <View key={label} className="flex-row items-center gap-3 mb-4">
          <View className="w-9 h-9 bg-primary/10 rounded-full items-center justify-center">
            <Ionicons name={icon as any} size={18} color="#3b82f6" />
          </View>
          <Text className="text-muted text-sm flex-1">{label}</Text>
        </View>
      ))}

      <View className="mt-4">
        <ActionButton
          label="Post a Job"
          icon="add-circle"
          onPress={() => router.push('/auth/register')}
        />
        <ActionButton
          label="Join as a Tradie"
          icon="construct-outline"
          onPress={() => router.push('/auth/register')}
          outline
        />
        <TouchableOpacity
          onPress={() => router.push('/auth/login')}
          className="items-center mt-2 py-2"
        >
          <Text className="text-muted text-sm">
            Already have an account?{' '}
            <Text className="text-primary font-semibold">Sign in</Text>
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

// ─── Authenticated Home ───────────────────────────────────────────────────────

function AuthHome() {
  const router = useRouter();
  const { user } = useAuth();

  const { data: subscription, isLoading: subLoading } = useQuery({
    queryKey: ['subscription'],
    queryFn: getSubscription,
    retry: 1,
  });

  const { data: leads, isLoading: leadsLoading } = useQuery({
    queryKey: ['myLeads'],
    queryFn: getMyLeads,
    enabled: user?.role === 'tradie',
    retry: 1,
  });

  const isTradie = user?.role === 'tradie';

  return (
    <ScrollView
      className="flex-1"
      contentContainerStyle={{ padding: 16 }}
      showsVerticalScrollIndicator={false}
    >
      {/* Greeting */}
      <View className="mb-5">
        <Text className="text-muted text-sm">Welcome back,</Text>
        <Text className="text-foreground text-2xl font-bold">{user?.name}</Text>
        <View className="flex-row items-center gap-1 mt-1">
          <View className="w-2 h-2 bg-success rounded-full" />
          <Text className="text-muted text-xs capitalize">{user?.role} account</Text>
        </View>
      </View>

      {/* Stats row */}
      <View className="flex-row mb-5">
        {subLoading ? (
          <ActivityIndicator color="#3b82f6" />
        ) : (
          <>
            <StatCard
              label={isTradie ? 'Credits Left' : 'Posts Left'}
              value={
                isTradie
                  ? subscription?.creditsRemaining ?? 0
                  : subscription?.postsRemaining === -1
                  ? '∞'
                  : (subscription?.postsRemaining ?? 0)
              }
              icon="wallet-outline"
            />
            {isTradie && (
              <StatCard
                label="Active Leads"
                value={leadsLoading ? '...' : leads?.length ?? 0}
                icon="trending-up-outline"
              />
            )}
            <StatCard
              label="Plan"
              value={subscription?.plan ?? '—'}
              icon="star-outline"
            />
          </>
        )}
      </View>

      {/* Quick actions */}
      <Text className="text-foreground font-semibold text-base mb-3">Quick Actions</Text>
      {isTradie ? (
        <>
          <ActionButton
            label="Browse Jobs"
            icon="briefcase-outline"
            onPress={() => router.push('/(tabs)/jobs')}
          />
          <ActionButton
            label="My Leads"
            icon="list-outline"
            onPress={() => router.push('/(tabs)/dashboard')}
            outline
          />
        </>
      ) : (
        <>
          <ActionButton
            label="Post a New Job"
            icon="add-circle-outline"
            onPress={() => router.push('/(tabs)/jobs')}
          />
          <ActionButton
            label="View My Jobs"
            icon="folder-open-outline"
            onPress={() => router.push('/(tabs)/dashboard')}
            outline
          />
        </>
      )}
      <ActionButton
        label="Upgrade Plan"
        icon="rocket-outline"
        onPress={() => router.push('/pricing')}
        outline
      />
    </ScrollView>
  );
}

// ─── Screen ───────────────────────────────────────────────────────────────────

export default function HomeScreen() {
  const { isAuthenticated, loading } = useAuth();

  if (loading) {
    return (
      <View className="flex-1 bg-background items-center justify-center">
        <ActivityIndicator size="large" color="#3b82f6" />
        <Text className="text-muted text-sm mt-3">Loading…</Text>
      </View>
    );
  }

  return (
    <View className="flex-1 bg-background">
      <View className="items-center pt-8 pb-4">
        <Logo />
      </View>
      {isAuthenticated ? <AuthHome /> : <GuestHero />}
    </View>
  );
}
