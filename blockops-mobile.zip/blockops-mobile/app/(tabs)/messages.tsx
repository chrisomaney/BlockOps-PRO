import React, { useCallback } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
} from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useQuery } from '@tanstack/react-query';
import { getConversations, Conversation } from '../../lib/api';
import { useAuth } from '../../lib/auth';

// ─── Conversation Item ────────────────────────────────────────────────────────

function ConversationItem({
  conversation,
  onPress,
}: {
  conversation: Conversation;
  onPress: () => void;
}) {
  const initials = conversation.otherName
    .split(' ')
    .map((n) => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);

  return (
    <TouchableOpacity
      onPress={onPress}
      activeOpacity={0.7}
      className="flex-row items-center bg-card border border-border rounded-xl p-4 mb-3"
    >
      {/* Avatar */}
      <View className="w-12 h-12 bg-primary/20 rounded-full items-center justify-center mr-4">
        <Text className="text-primary font-bold text-base">{initials}</Text>
      </View>

      {/* Content */}
      <View className="flex-1">
        <Text className="text-foreground font-semibold text-base" numberOfLines={1}>
          {conversation.otherName}
        </Text>
        {conversation.job?.title && (
          <Text className="text-muted text-xs mt-0.5" numberOfLines={1}>
            Re: {conversation.job.title}
          </Text>
        )}
        {conversation.lastMessage && (
          <Text className="text-muted text-sm mt-1" numberOfLines={1}>
            {conversation.lastMessage}
          </Text>
        )}
      </View>

      {/* Chevron */}
      <Ionicons name="chevron-forward" size={18} color="#8892a4" />
    </TouchableOpacity>
  );
}

// ─── Empty State ──────────────────────────────────────────────────────────────

function EmptyState() {
  return (
    <View className="flex-1 items-center justify-center py-20">
      <Ionicons name="chatbubbles-outline" size={52} color="#1e2535" />
      <Text className="text-muted text-base mt-4 text-center">No conversations yet</Text>
      <Text className="text-muted/60 text-sm mt-2 text-center px-10">
        When tradies express interest in your jobs, conversations will appear here.
      </Text>
    </View>
  );
}

// ─── Screen ───────────────────────────────────────────────────────────────────

export default function MessagesScreen() {
  const router = useRouter();
  const { isAuthenticated } = useAuth();

  const { data: conversations, isLoading, error, refetch, isFetching } = useQuery({
    queryKey: ['conversations'],
    queryFn: getConversations,
    enabled: isAuthenticated,
    staleTime: 1000 * 30,
  });

  const onRefresh = useCallback(() => refetch(), [refetch]);

  if (!isAuthenticated) {
    return (
      <View className="flex-1 bg-background items-center justify-center px-8">
        <Ionicons name="lock-closed-outline" size={52} color="#1e2535" />
        <Text className="text-foreground text-xl font-bold mt-5 text-center">
          Sign in to view messages
        </Text>
        <Text className="text-muted text-sm mt-2 text-center">
          Create an account or sign in to chat with tradies and clients.
        </Text>
        <TouchableOpacity
          onPress={() => router.push('/auth/login')}
          className="bg-primary rounded-xl px-8 py-4 mt-6"
        >
          <Text className="text-white font-semibold text-base">Sign In</Text>
        </TouchableOpacity>
      </View>
    );
  }

  if (isLoading) {
    return (
      <View className="flex-1 bg-background items-center justify-center">
        <ActivityIndicator size="large" color="#3b82f6" />
        <Text className="text-muted text-sm mt-3">Loading messages…</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View className="flex-1 bg-background items-center justify-center px-6">
        <Ionicons name="cloud-offline-outline" size={48} color="#ef4444" />
        <Text className="text-danger text-base mt-3 text-center">Failed to load messages</Text>
        <TouchableOpacity
          onPress={() => refetch()}
          className="mt-4 px-6 py-3 border border-primary rounded-xl"
        >
          <Text className="text-primary font-semibold">Retry</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View className="flex-1 bg-background">
      <View className="px-4 pt-4 pb-2">
        <Text className="text-foreground text-xl font-bold">Messages</Text>
        <Text className="text-muted text-sm mt-0.5">
          {conversations?.length ?? 0} conversation{conversations?.length !== 1 ? 's' : ''}
        </Text>
      </View>

      <FlatList
        data={conversations}
        keyExtractor={(item) => `${item.jobId}-${item.otherId}`}
        renderItem={({ item }) => (
          <ConversationItem
            conversation={item}
            onPress={() =>
              router.push(`/messages/${item.jobId}/${item.otherId}`)
            }
          />
        )}
        contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 20, flexGrow: 1 }}
        ListEmptyComponent={<EmptyState />}
        refreshControl={
          <RefreshControl
            refreshing={isFetching && !isLoading}
            onRefresh={onRefresh}
            tintColor="#3b82f6"
          />
        }
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}
