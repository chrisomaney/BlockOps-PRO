import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  TextInput,
  FlatList,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
  Alert,
} from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useQuery } from '@tanstack/react-query';
import { getJobs, postJob, Job } from '../../lib/api';
import { useAuth } from '../../lib/auth';
import JobCard from '../../components/JobCard';

// ─── Trade Types ──────────────────────────────────────────────────────────────

const TRADE_TYPES = [
  'All',
  'Plumbing',
  'Electrical',
  'HVAC',
  'Carpentry',
  'Painting',
  'Roofing',
  'Tiling',
  'Landscaping',
  'Cleaning',
  'Pest Control',
  'Security',
  'Locksmith',
  'Glazing',
  'Flooring',
  'Other',
];

// ─── Filter Chip ──────────────────────────────────────────────────────────────

function FilterChip({
  label,
  active,
  onPress,
}: {
  label: string;
  active: boolean;
  onPress: () => void;
}) {
  return (
    <TouchableOpacity
      onPress={onPress}
      activeOpacity={0.7}
      className={`px-4 py-2 rounded-full mr-2 border ${
        active
          ? 'bg-primary border-primary'
          : 'bg-transparent border-border'
      }`}
    >
      <Text
        className={`text-sm font-medium ${active ? 'text-white' : 'text-muted'}`}
      >
        {label}
      </Text>
    </TouchableOpacity>
  );
}

// ─── Post Job Modal ───────────────────────────────────────────────────────────

function PostJobForm({ onClose }: { onClose: () => void }) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [location, setLocation] = useState('');
  const [tradeType, setTradeType] = useState('');
  const [budget, setBudget] = useState('');
  const [isUrgent, setIsUrgent] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async () => {
    if (!title.trim() || !location.trim() || !tradeType.trim()) {
      Alert.alert('Missing Fields', 'Please fill in title, location, and trade type.');
      return;
    }
    setSubmitting(true);
    try {
      await postJob({
        title: title.trim(),
        description: description.trim(),
        location: location.trim(),
        tradeType: tradeType.trim(),
        budget: budget ? parseFloat(budget) : undefined,
        isUrgent,
      });
      Alert.alert('Job Posted!', 'Your job has been posted successfully.');
      onClose();
    } catch (err: any) {
      Alert.alert('Error', err?.response?.data?.message ?? 'Failed to post job. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const inputClass =
    'bg-card border border-border rounded-xl px-4 py-3 text-foreground text-sm mb-3';

  return (
    <View className="bg-background flex-1 px-5 pt-5">
      <View className="flex-row items-center justify-between mb-5">
        <Text className="text-foreground text-xl font-bold">Post a Job</Text>
        <TouchableOpacity onPress={onClose}>
          <Ionicons name="close" size={26} color="#8892a4" />
        </TouchableOpacity>
      </View>

      <TextInput
        className={inputClass}
        placeholder="Job title *"
        placeholderTextColor="#8892a4"
        value={title}
        onChangeText={setTitle}
      />
      <TextInput
        className={inputClass}
        placeholder="Description"
        placeholderTextColor="#8892a4"
        value={description}
        onChangeText={setDescription}
        multiline
        numberOfLines={3}
        textAlignVertical="top"
        style={{ minHeight: 80 }}
      />
      <TextInput
        className={inputClass}
        placeholder="Location / suburb *"
        placeholderTextColor="#8892a4"
        value={location}
        onChangeText={setLocation}
      />
      <TextInput
        className={inputClass}
        placeholder="Trade type *"
        placeholderTextColor="#8892a4"
        value={tradeType}
        onChangeText={setTradeType}
      />
      <TextInput
        className={inputClass}
        placeholder="Budget (AUD)"
        placeholderTextColor="#8892a4"
        value={budget}
        onChangeText={setBudget}
        keyboardType="numeric"
      />

      <TouchableOpacity
        onPress={() => setIsUrgent(!isUrgent)}
        className="flex-row items-center gap-3 mb-5"
      >
        <View
          className={`w-6 h-6 rounded border-2 items-center justify-center ${
            isUrgent ? 'bg-primary border-primary' : 'border-border'
          }`}
        >
          {isUrgent && <Ionicons name="checkmark" size={14} color="#fff" />}
        </View>
        <Text className="text-muted text-sm">Mark as urgent</Text>
      </TouchableOpacity>

      <TouchableOpacity
        onPress={handleSubmit}
        disabled={submitting}
        activeOpacity={0.8}
        className="bg-primary rounded-xl py-4 items-center"
      >
        {submitting ? (
          <ActivityIndicator color="#fff" />
        ) : (
          <Text className="text-white font-semibold text-base">Post Job</Text>
        )}
      </TouchableOpacity>
    </View>
  );
}

// ─── Empty State ──────────────────────────────────────────────────────────────

function EmptyState({ search }: { search: string }) {
  return (
    <View className="flex-1 items-center justify-center py-20">
      <Ionicons name="briefcase-outline" size={48} color="#1e2535" />
      <Text className="text-muted text-base mt-4 text-center">
        {search ? `No jobs found for "${search}"` : 'No jobs available right now'}
      </Text>
      <Text className="text-muted/60 text-sm mt-2 text-center px-10">
        Pull down to refresh or adjust your filters
      </Text>
    </View>
  );
}

// ─── Screen ───────────────────────────────────────────────────────────────────

export default function JobsScreen() {
  const router = useRouter();
  const { user } = useAuth();

  const [search, setSearch] = useState('');
  const [selectedTrade, setSelectedTrade] = useState('All');
  const [showPostForm, setShowPostForm] = useState(false);

  const { data: jobs, isLoading, error, refetch, isFetching } = useQuery({
    queryKey: ['jobs', search, selectedTrade],
    queryFn: () =>
      getJobs({
        search: search || undefined,
        tradeType: selectedTrade !== 'All' ? selectedTrade : undefined,
      }),
    staleTime: 1000 * 30,
  });

  const onRefresh = useCallback(() => {
    refetch();
  }, [refetch]);

  if (showPostForm && user?.role === 'client') {
    return <PostJobForm onClose={() => { setShowPostForm(false); refetch(); }} />;
  }

  return (
    <View className="flex-1 bg-background">
      {/* Header */}
      <View className="px-4 pt-4 pb-2">
        <View className="flex-row items-center justify-between mb-3">
          <Text className="text-foreground text-xl font-bold">
            {user?.role === 'client' ? 'Job Board' : 'Browse Jobs'}
          </Text>
          {user?.role === 'client' && (
            <TouchableOpacity
              onPress={() => setShowPostForm(true)}
              className="bg-primary px-4 py-2 rounded-xl flex-row items-center gap-2"
            >
              <Ionicons name="add" size={18} color="#fff" />
              <Text className="text-white font-semibold text-sm">Post Job</Text>
            </TouchableOpacity>
          )}
        </View>

        {/* Search input */}
        <View className="flex-row items-center bg-card border border-border rounded-xl px-4 mb-3">
          <Ionicons name="search-outline" size={18} color="#8892a4" />
          <TextInput
            className="flex-1 py-3 px-3 text-foreground text-sm"
            placeholder="Search jobs..."
            placeholderTextColor="#8892a4"
            value={search}
            onChangeText={setSearch}
            returnKeyType="search"
          />
          {search.length > 0 && (
            <TouchableOpacity onPress={() => setSearch('')}>
              <Ionicons name="close-circle" size={18} color="#8892a4" />
            </TouchableOpacity>
          )}
        </View>
      </View>

      {/* Trade type filters */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        className="mb-2"
        contentContainerStyle={{ paddingHorizontal: 16 }}
      >
        {TRADE_TYPES.map((trade) => (
          <FilterChip
            key={trade}
            label={trade}
            active={selectedTrade === trade}
            onPress={() => setSelectedTrade(trade)}
          />
        ))}
      </ScrollView>

      {/* Results count */}
      {!isLoading && jobs && (
        <Text className="text-muted text-xs px-4 mb-2">
          {jobs.length} {jobs.length === 1 ? 'job' : 'jobs'} found
        </Text>
      )}

      {/* Job list */}
      {isLoading ? (
        <View className="flex-1 items-center justify-center">
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text className="text-muted text-sm mt-3">Loading jobs…</Text>
        </View>
      ) : error ? (
        <View className="flex-1 items-center justify-center px-6">
          <Ionicons name="cloud-offline-outline" size={48} color="#ef4444" />
          <Text className="text-danger text-base mt-3 text-center">Failed to load jobs</Text>
          <TouchableOpacity onPress={() => refetch()} className="mt-4 px-6 py-3 border border-primary rounded-xl">
            <Text className="text-primary font-semibold">Retry</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <FlatList
          data={jobs}
          keyExtractor={(item) => String(item.id)}
          renderItem={({ item }) => (
            <JobCard
              job={item}
              onPress={() => router.push(`/jobs/${item.id}`)}
            />
          )}
          contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 20, flexGrow: 1 }}
          ListEmptyComponent={<EmptyState search={search} />}
          refreshControl={
            <RefreshControl
              refreshing={isFetching && !isLoading}
              onRefresh={onRefresh}
              tintColor="#3b82f6"
            />
          }
          showsVerticalScrollIndicator={false}
        />
      )}
    </View>
  );
}
