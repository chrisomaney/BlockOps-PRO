import React from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

export interface Plan {
  id: string;
  name: string;
  price: number;
  period: string;
  credits: number; // -1 = unlimited
  features: string[];
  highlighted?: boolean;
}

interface PlanCardProps {
  plan: Plan;
  selected: boolean;
  onSelect: () => void;
}

export default function PlanCard({ plan, selected, onSelect }: PlanCardProps) {
  const { name, price, period, credits, features, highlighted } = plan;

  const creditsLabel =
    credits === -1
      ? 'Unlimited'
      : `${credits} credit${credits !== 1 ? 's' : ''}`;

  return (
    <TouchableOpacity
      onPress={onSelect}
      activeOpacity={0.8}
      className={`rounded-xl border p-5 mb-3 ${
        selected
          ? 'bg-primary/10 border-primary'
          : highlighted
          ? 'bg-card border-primary/40'
          : 'bg-card border-border'
      }`}
    >
      {/* Header row */}
      <View className="flex-row items-start justify-between mb-3">
        <View className="flex-1">
          <View className="flex-row items-center gap-2">
            <Text className="text-foreground text-lg font-bold">{name}</Text>
            {highlighted && !selected && (
              <View className="bg-primary/20 rounded-full px-2.5 py-0.5">
                <Text className="text-primary text-xs font-semibold">Popular</Text>
              </View>
            )}
            {selected && (
              <View className="bg-primary rounded-full px-2.5 py-0.5">
                <Text className="text-white text-xs font-semibold">Selected</Text>
              </View>
            )}
          </View>
          <View className="flex-row items-baseline gap-1 mt-1">
            <Text className="text-foreground text-3xl font-bold">${price}</Text>
            <Text className="text-muted text-sm">{period}</Text>
          </View>
        </View>

        {/* Selection indicator */}
        <View
          className={`w-6 h-6 rounded-full border-2 items-center justify-center mt-1 ${
            selected ? 'bg-primary border-primary' : 'bg-transparent border-border'
          }`}
        >
          {selected && <Ionicons name="checkmark" size={14} color="#fff" />}
        </View>
      </View>

      {/* Credits highlight */}
      <View className="bg-primary/10 rounded-xl px-4 py-2.5 mb-4 flex-row items-center gap-2">
        <Ionicons name="wallet-outline" size={16} color="#3b82f6" />
        <Text className="text-primary font-semibold text-sm">{creditsLabel}/month</Text>
      </View>

      {/* Feature list */}
      <View className="gap-2">
        {features.map((feature) => (
          <View key={feature} className="flex-row items-center gap-2.5">
            <View className="w-5 h-5 bg-success/20 rounded-full items-center justify-center">
              <Ionicons name="checkmark" size={12} color="#22c55e" />
            </View>
            <Text className="text-muted text-sm flex-1">{feature}</Text>
          </View>
        ))}
      </View>
    </TouchableOpacity>
  );
}
