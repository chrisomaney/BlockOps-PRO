import React from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Job } from '../lib/api';

interface JobCardProps {
  job: Job;
  onPress: () => void;
}

// ─── Trade Type Badge ─────────────────────────────────────────────────────────

const TRADE_COLORS: Record<string, string> = {
  Plumbing: '#3b82f6',
  Electrical: '#f59e0b',
  HVAC: '#06b6d4',
  Carpentry: '#a78bfa',
  Painting: '#ec4899',
  Roofing: '#f97316',
  Tiling: '#10b981',
  Landscaping: '#22c55e',
  Cleaning: '#64748b',
  'Pest Control': '#8b5cf6',
  Security: '#ef4444',
  Locksmith: '#3b82f6',
  Glazing: '#0ea5e9',
  Flooring: '#d97706',
};

function TradeTypeBadge({ tradeType }: { tradeType: string }) {
  const color = TRADE_COLORS[tradeType] ?? '#8892a4';
  return (
    <View
      style={{ backgroundColor: color + '20', borderColor: color }}
      className="border rounded-full px-3 py-0.5"
    >
      <Text style={{ color }} className="text-xs font-medium">
        {tradeType}
      </Text>
    </View>
  );
}

// ─── Job Card ─────────────────────────────────────────────────────────────────

export default function JobCard({ job, onPress }: JobCardProps) {
  const timeAgo = job.createdAt
    ? getTimeAgo(new Date(job.createdAt))
    : null;

  return (
    <TouchableOpacity
      onPress={onPress}
      activeOpacity={0.7}
      className="bg-card border border-border rounded-xl p-4 mb-3"
    >
      {/* Top row: title + urgent badge */}
      <View className="flex-row items-start justify-between gap-3 mb-3">
        <Text
          className="text-foreground font-bold text-base flex-1 leading-snug"
          numberOfLines={2}
        >
          {job.title}
        </Text>
        {job.isUrgent && (
          <View className="bg-danger/20 border border-danger rounded-full px-2.5 py-0.5">
            <Text className="text-danger text-xs font-bold">URGENT</Text>
          </View>
        )}
      </View>

      {/* Location */}
      <View className="flex-row items-center gap-1.5 mb-2">
        <Ionicons name="location-outline" size={14} color="#8892a4" />
        <Text className="text-muted text-sm" numberOfLines={1}>
          {job.location}
        </Text>
      </View>

      {/* Description preview */}
      {job.description && (
        <Text className="text-muted text-sm mb-3 leading-relaxed" numberOfLines={2}>
          {job.description}
        </Text>
      )}

      {/* Bottom row: trade type + budget + time */}
      <View className="flex-row items-center justify-between flex-wrap gap-2 mt-1">
        <View className="flex-row items-center gap-2 flex-wrap">
          <TradeTypeBadge tradeType={job.tradeType} />
          {job.budget && (
            <View className="flex-row items-center gap-1">
              <Ionicons name="cash-outline" size={13} color="#22c55e" />
              <Text className="text-success text-xs font-semibold">
                ${job.budget.toLocaleString()}
              </Text>
            </View>
          )}
        </View>
        <View className="flex-row items-center gap-1">
          {timeAgo && (
            <>
              <Ionicons name="time-outline" size={12} color="#8892a4" />
              <Text className="text-muted text-xs">{timeAgo}</Text>
            </>
          )}
          <Ionicons name="chevron-forward" size={14} color="#1e2535" style={{ marginLeft: 4 }} />
        </View>
      </View>
    </TouchableOpacity>
  );
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function getTimeAgo(date: Date): string {
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMins / 60);
  const diffDays = Math.floor(diffHours / 24);

  if (diffMins < 1) return 'just now';
  if (diffMins < 60) return `${diffMins}m ago`;
  if (diffHours < 24) return `${diffHours}h ago`;
  if (diffDays < 7) return `${diffDays}d ago`;
  return date.toLocaleDateString('en-AU', { day: 'numeric', month: 'short' });
}
