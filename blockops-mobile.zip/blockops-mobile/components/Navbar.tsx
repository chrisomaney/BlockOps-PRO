import React from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

interface NavbarProps {
  title?: string;
  showBack?: boolean;
  onBack?: () => void;
  rightElement?: React.ReactNode;
}

/**
 * Reusable header / navbar component.
 * Uses safe area insets so it renders correctly below notches and status bars.
 * For most screens, the Expo Router Stack header is used automatically.
 * Use this component when you need a custom header outside of the Stack navigator.
 */
export default function Navbar({
  title = 'BlockOps Pro',
  showBack = true,
  onBack,
  rightElement,
}: NavbarProps) {
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const handleBack = () => {
    if (onBack) {
      onBack();
    } else if (router.canGoBack()) {
      router.back();
    }
  };

  return (
    <View
      style={{ paddingTop: insets.top }}
      className="bg-background border-b border-border"
    >
      <View className="flex-row items-center px-4 py-3 min-h-[52px]">
        {/* Back button */}
        {showBack ? (
          <TouchableOpacity
            onPress={handleBack}
            hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
            className="w-9 h-9 items-center justify-center rounded-xl"
          >
            <Ionicons name="chevron-back" size={24} color="#f0f4ff" />
          </TouchableOpacity>
        ) : (
          // Logo mark when no back button
          <View className="w-9 h-9 bg-primary rounded-xl items-center justify-center">
            <Ionicons name="construct" size={18} color="#fff" />
          </View>
        )}

        {/* Title */}
        <View className="flex-1 items-center">
          {title === 'BlockOps Pro' ? (
            <View className="flex-row items-center gap-1">
              <Text className="text-primary text-base font-bold">BlockOps</Text>
              <Text className="text-foreground text-base font-bold">Pro</Text>
            </View>
          ) : (
            <Text className="text-foreground text-base font-semibold" numberOfLines={1}>
              {title}
            </Text>
          )}
        </View>

        {/* Right element (e.g. settings icon, avatar) */}
        <View className="w-9 h-9 items-center justify-center">
          {rightElement ?? null}
        </View>
      </View>
    </View>
  );
}
