// ─── API ──────────────────────────────────────────────────────────────────────

export const API_BASE_URL = 'https://tasker.blockops.au/api';
export const TOKEN_STORAGE_KEY = 'blockops_token';

// ─── Trade Types ──────────────────────────────────────────────────────────────

export const TRADE_TYPES = [
  'Plumbing',
  'Electrical',
  'HVAC',
  'Carpentry',
  'Painting',
  'Roofing',
  'Tiling',
  'Landscaping',
  'Cleaning',
  'Pest Control',
  'Security',
  'Locksmith',
  'Glazing',
  'Flooring',
  'General Maintenance',
  'Other',
] as const;

export type TradeType = typeof TRADE_TYPES[number];

// ─── Client Types ─────────────────────────────────────────────────────────────

export const CLIENT_TYPES = [
  { id: 'property_manager', label: 'Property Manager' },
  { id: 'real_estate', label: 'Real Estate Agency' },
  { id: 'building_manager', label: 'Building Manager' },
  { id: 'strata_manager', label: 'Strata Manager' },
  { id: 'facilities_manager', label: 'Facilities Manager' },
  { id: 'other', label: 'Other' },
] as const;

// ─── Tradie Plans ─────────────────────────────────────────────────────────────

export const TRADIE_PLANS = [
  { id: 'starter', name: 'Starter', price: 39, credits: 5 },
  { id: 'pro', name: 'Pro', price: 59, credits: 12 },
  { id: 'elite', name: 'Elite', price: 99, credits: 25 },
] as const;

// ─── Client Plans ─────────────────────────────────────────────────────────────

export const CLIENT_PLANS = [
  { id: 'basic', name: 'Basic', price: 29, posts: 5 },
  { id: 'business', name: 'Business', price: 49, posts: 15 },
  { id: 'enterprise', name: 'Enterprise', price: 79, posts: -1 }, // -1 = unlimited
] as const;

// ─── Colors ───────────────────────────────────────────────────────────────────

export const COLORS = {
  background: '#0f1117',
  card: '#161b27',
  border: '#1e2535',
  primary: '#3b82f6',
  primaryDark: '#2563eb',
  foreground: '#f0f4ff',
  muted: '#8892a4',
  danger: '#ef4444',
  success: '#22c55e',
  warning: '#f59e0b',
} as const;

// ─── Job Status ───────────────────────────────────────────────────────────────

export const JOB_STATUS_COLORS: Record<string, string> = {
  open: '#22c55e',
  closed: '#8892a4',
  in_progress: '#3b82f6',
  completed: '#f59e0b',
};

// ─── Lead Status ──────────────────────────────────────────────────────────────

export const LEAD_STATUS_COLORS: Record<string, string> = {
  pending: '#f59e0b',
  accepted: '#22c55e',
  rejected: '#ef4444',
  completed: '#3b82f6',
};
