import axios, { AxiosError, InternalAxiosRequestConfig } from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

// ─── Constants ────────────────────────────────────────────────────────────────

export const BASE_URL = 'https://tasker.blockops.au/api';
export const TOKEN_KEY = 'blockops_token';

// ─── Axios Instance ───────────────────────────────────────────────────────────

const api = axios.create({
  baseURL: BASE_URL,
  timeout: 15000,
  headers: {
    'Content-Type': 'application/json',
    Accept: 'application/json',
  },
});

// ─── Request Interceptor ─────────────────────────────────────────────────────

api.interceptors.request.use(
  async (config: InternalAxiosRequestConfig) => {
    const token = await AsyncStorage.getItem(TOKEN_KEY);
    if (token && config.headers) {
      config.headers['x-session-token'] = token;
    }
    return config;
  },
  (error: AxiosError) => Promise.reject(error),
);

// ─── Response Interceptor ────────────────────────────────────────────────────

api.interceptors.response.use(
  (response) => response,
  (error: AxiosError) => {
    const status = error.response?.status;
    if (status === 401) {
      // Token expired or invalid — caller should handle by clearing session
      AsyncStorage.removeItem(TOKEN_KEY).catch(() => {});
    }
    return Promise.reject(error);
  },
);

// ─── Types ────────────────────────────────────────────────────────────────────

export interface LoginResponse {
  token: string;
  user: User;
}

export interface User {
  id: string | number;
  name: string;
  email: string;
  role: 'tradie' | 'client' | 'admin';
  phone?: string;
  createdAt?: string;
}

export interface Job {
  id: string | number;
  title: string;
  description: string;
  location: string;
  tradeType: string;
  budget?: number;
  isUrgent?: boolean;
  status: string;
  clientId?: string | number;
  createdAt?: string;
  updatedAt?: string;
}

export interface Lead {
  id: string | number;
  jobId: string | number;
  tradieId: string | number;
  message?: string;
  quote?: number;
  status: string;
  createdAt?: string;
  job?: Job;
  tradie?: User;
}

export interface Message {
  id: string | number;
  jobId: string | number;
  senderId: string | number;
  receiverId: string | number;
  content: string;
  createdAt?: string;
}

export interface Conversation {
  jobId: string | number;
  otherId: string | number;
  otherName: string;
  lastMessage?: string;
  updatedAt?: string;
  job?: Job;
}

export interface Subscription {
  id: string | number;
  plan: string;
  status: string;
  creditsRemaining?: number;
  postsRemaining?: number;
  expiresAt?: string;
}

export interface TradieProfile {
  id?: string | number;
  userId?: string | number;
  businessName: string;
  abn: string;
  tradeTypes: string[];
  serviceAreas: string[];
  bio?: string;
  verified?: boolean;
  rating?: number;
  reviewCount?: number;
}

export interface ClientProfile {
  id?: string | number;
  userId?: string | number;
  companyName: string;
  abn?: string;
  clientType: string;
  address: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  total?: number;
  page?: number;
  perPage?: number;
}

// ─── Auth ─────────────────────────────────────────────────────────────────────

export const login = async (email: string, password: string): Promise<LoginResponse> => {
  const res = await api.post<LoginResponse>('/auth/login', { email, password });
  return res.data;
};

export const register = async (
  name: string,
  email: string,
  password: string,
  role: 'tradie' | 'client',
  phone?: string,
): Promise<LoginResponse> => {
  const res = await api.post<LoginResponse>('/auth/register', {
    name,
    email,
    password,
    role,
    phone,
  });
  return res.data;
};

export const getMe = async (): Promise<User> => {
  const res = await api.get<User>('/auth/me');
  return res.data;
};

// ─── Jobs ─────────────────────────────────────────────────────────────────────

export interface GetJobsParams {
  search?: string;
  tradeType?: string;
  location?: string;
  page?: number;
  limit?: number;
}

export const getJobs = async (params?: GetJobsParams): Promise<Job[]> => {
  const res = await api.get<Job[] | PaginatedResponse<Job>>('/jobs', { params });
  return Array.isArray(res.data) ? res.data : res.data.data;
};

export const getJob = async (id: string | number): Promise<Job> => {
  const res = await api.get<Job>(`/jobs/${id}`);
  return res.data;
};

export interface PostJobData {
  title: string;
  description: string;
  location: string;
  tradeType: string;
  budget?: number;
  isUrgent?: boolean;
}

export const postJob = async (data: PostJobData): Promise<Job> => {
  const res = await api.post<Job>('/jobs', data);
  return res.data;
};

// ─── Leads ────────────────────────────────────────────────────────────────────

export interface SubmitLeadData {
  jobId: string | number;
  message?: string;
  quote?: number;
}

export const submitLead = async (data: SubmitLeadData): Promise<Lead> => {
  const res = await api.post<Lead>('/leads', data);
  return res.data;
};

export const getMyLeads = async (): Promise<Lead[]> => {
  const res = await api.get<Lead[] | PaginatedResponse<Lead>>('/leads/mine');
  return Array.isArray(res.data) ? res.data : res.data.data;
};

export const getJobLeads = async (jobId: string | number): Promise<Lead[]> => {
  const res = await api.get<Lead[] | PaginatedResponse<Lead>>(`/jobs/${jobId}/leads`);
  return Array.isArray(res.data) ? res.data : res.data.data;
};

// ─── Messages ─────────────────────────────────────────────────────────────────

export const getConversations = async (): Promise<Conversation[]> => {
  const res = await api.get<Conversation[]>('/messages/conversations');
  return res.data;
};

export const getMessages = async (
  jobId: string | number,
  otherId: string | number,
): Promise<Message[]> => {
  const res = await api.get<Message[]>(`/messages/${jobId}/${otherId}`);
  return res.data;
};

export interface SendMessageData {
  jobId: string | number;
  receiverId: string | number;
  content: string;
}

export const sendMessage = async (data: SendMessageData): Promise<Message> => {
  const res = await api.post<Message>('/messages', data);
  return res.data;
};

// ─── Subscriptions ────────────────────────────────────────────────────────────

export const getSubscription = async (): Promise<Subscription> => {
  const res = await api.get<Subscription>('/subscriptions/mine');
  return res.data;
};

export const selectPlan = async (plan: string): Promise<Subscription> => {
  const res = await api.post<Subscription>('/subscriptions/select', { plan });
  return res.data;
};

// ─── Tradie Profile ───────────────────────────────────────────────────────────

export const getTradieProfile = async (): Promise<TradieProfile> => {
  const res = await api.get<TradieProfile>('/profiles/tradie');
  return res.data;
};

export const createTradieProfile = async (data: TradieProfile): Promise<TradieProfile> => {
  const res = await api.post<TradieProfile>('/profiles/tradie', data);
  return res.data;
};

export const updateTradieProfile = async (data: Partial<TradieProfile>): Promise<TradieProfile> => {
  const res = await api.put<TradieProfile>('/profiles/tradie', data);
  return res.data;
};

// ─── Client Profile ───────────────────────────────────────────────────────────

export const getClientProfile = async (): Promise<ClientProfile> => {
  const res = await api.get<ClientProfile>('/profiles/client');
  return res.data;
};

export const createClientProfile = async (data: ClientProfile): Promise<ClientProfile> => {
  const res = await api.post<ClientProfile>('/profiles/client', data);
  return res.data;
};

export const updateClientProfile = async (data: Partial<ClientProfile>): Promise<ClientProfile> => {
  const res = await api.put<ClientProfile>('/profiles/client', data);
  return res.data;
};

// ─── Document Upload ──────────────────────────────────────────────────────────

export interface UploadDocumentData {
  uri: string;
  name: string;
  type: string;
  docType: string;
}

export const uploadDocument = async (data: UploadDocumentData): Promise<{ url: string }> => {
  const formData = new FormData();
  formData.append('file', {
    uri: data.uri,
    name: data.name,
    type: data.type,
  } as unknown as Blob);
  formData.append('docType', data.docType);

  const res = await api.post<{ url: string }>('/documents/upload', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });
  return res.data;
};

export default api;
