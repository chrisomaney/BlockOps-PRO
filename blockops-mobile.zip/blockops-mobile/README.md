# BlockOps Pro — Mobile App

A React Native / Expo mobile app for the **BlockOps Pro** B2B verified trades marketplace.

## Tech Stack

| Technology | Version | Purpose |
|---|---|---|
| Expo | ~51.0.0 | Managed workflow |
| React Native | 0.74.5 | Cross-platform mobile |
| TypeScript | ~5.3.3 | Type safety |
| Expo Router | ~3.5.0 | File-based routing |
| NativeWind v4 | ^4.0.1 | Tailwind CSS for React Native |
| React Query | ^5.0.0 | Server state management |
| Axios | ^1.7.0 | HTTP client |
| AsyncStorage | 1.23.1 | Session token persistence |

## Getting Started

### Prerequisites

- Node.js 18+
- Expo CLI: `npm install -g expo-cli`
- iOS: Xcode 15+ (macOS only)
- Android: Android Studio + Android SDK

### Installation

```bash
cd blockops-mobile
npm install
```

### Development

```bash
# Start the development server
npm start

# iOS
npm run ios

# Android
npm run android

# Web
npm run web
```

### Environment

The API base URL is set to `https://tasker.blockops.au/api` in `lib/api.ts`.

No `.env` file is required for development. The app uses `x-session-token` header for authentication, stored in AsyncStorage under `blockops_token`.

## Project Structure

```
blockops-mobile/
├── app/                          # Expo Router screens
│   ├── _layout.tsx               # Root layout (providers)
│   ├── (tabs)/                   # Bottom tab navigator
│   │   ├── _layout.tsx           # Tab bar config
│   │   ├── index.tsx             # Home screen
│   │   ├── jobs.tsx              # Job board
│   │   ├── messages.tsx          # Conversations list
│   │   └── dashboard.tsx         # User dashboard
│   ├── jobs/
│   │   └── [id].tsx              # Job detail
│   ├── messages/
│   │   └── [jobId]/
│   │       └── [otherId].tsx     # Message thread
│   ├── auth/
│   │   ├── login.tsx
│   │   └── register.tsx
│   ├── onboarding/
│   │   ├── tradie.tsx            # Tradie 3-step onboarding
│   │   └── client.tsx            # Client 2-step onboarding
│   └── pricing.tsx               # Plan selection
├── components/
│   ├── JobCard.tsx               # Reusable job card
│   ├── PlanCard.tsx              # Reusable pricing plan card
│   └── Navbar.tsx                # Reusable header / navbar
├── lib/
│   ├── api.ts                    # Axios instance + all API functions
│   ├── auth.tsx                  # AuthContext + useAuth hook
│   ├── constants.ts              # App-wide constants
│   └── utils.ts                  # Utility functions
├── assets/                       # App icons & splash screen
│   └── README.md                 # Asset replacement instructions
├── app.json                      # Expo configuration
├── babel.config.js
├── metro.config.js
├── tailwind.config.js
├── tsconfig.json
├── global.css                    # Tailwind base styles
└── nativewind-env.d.ts           # NativeWind TypeScript types
```

## Authentication Flow

1. User registers/logs in → API returns `{ token, user }`
2. Token stored in `AsyncStorage` under key `blockops_token`
3. All API requests include `x-session-token: <token>` header
4. On app start, token is restored and `/auth/me` is called to re-hydrate user state
5. 401 responses automatically clear the token

## User Roles

- **Tradie** — Browses jobs, expresses interest (uses credits), manages profile/documents
- **Client** — Posts jobs, reviews leads from tradies, manages subscription

## Subscription Plans

### Tradies
| Plan | Price | Credits |
|---|---|---|
| Starter | $39/mo | 5 |
| Pro | $59/mo | 12 |
| Elite | $99/mo | 25 |

### Clients
| Plan | Price | Posts |
|---|---|---|
| Basic | $29/mo | 5 |
| Business | $49/mo | 15 |
| Enterprise | $79/mo | Unlimited |

## Building for Production

```bash
# Install EAS CLI
npm install -g eas-cli

# Configure EAS project
eas build:configure

# Build for iOS
eas build --platform ios

# Build for Android
eas build --platform android

# Build for both
eas build --platform all
```

Update the `eas.projectId` in `app.json` with your actual EAS project ID before building.

## Assets

Before building for production, replace the placeholder asset references in `assets/` with actual branded assets. See `assets/README.md` for specifications.

## API Reference

All API functions are exported from `lib/api.ts`. See the source file for full type signatures.

| Function | Method | Endpoint |
|---|---|---|
| `login` | POST | `/auth/login` |
| `register` | POST | `/auth/register` |
| `getMe` | GET | `/auth/me` |
| `getJobs` | GET | `/jobs` |
| `getJob` | GET | `/jobs/:id` |
| `postJob` | POST | `/jobs` |
| `submitLead` | POST | `/leads` |
| `getMyLeads` | GET | `/leads/mine` |
| `getConversations` | GET | `/messages/conversations` |
| `getMessages` | GET | `/messages/:jobId/:otherId` |
| `sendMessage` | POST | `/messages` |
| `getSubscription` | GET | `/subscriptions/mine` |
| `selectPlan` | POST | `/subscriptions/select` |
| `getTradieProfile` | GET | `/profiles/tradie` |
| `createTradieProfile` | POST | `/profiles/tradie` |
| `getClientProfile` | GET | `/profiles/client` |
| `createClientProfile` | POST | `/profiles/client` |
| `uploadDocument` | POST | `/documents/upload` |
